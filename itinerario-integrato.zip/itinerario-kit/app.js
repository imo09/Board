/* ---- utilità ---- */
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));
const H = s => { const p = s.split(':'); return +p[0] + (+p[1]) / 60; };
const fmtH = h => { const m = Math.round(h * 60); return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
const euro = n => n.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
const dec = (n, d) => n.toLocaleString('it-IT', { minimumFractionDigits: d, maximumFractionDigits: d });
const icon = id => '<svg class="i" aria-hidden="true"><use href="#i-' + id + '"/></svg>';
const ext = (href, label, cls) => '<a class="btn' + (cls ? ' ' + cls : '') + '" href="' + esc(href) + '" target="_blank" rel="noopener">' + label + '</a>';
const WD = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'], MO = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
const dlab = iso => { const a = iso.split('-').map(Number); return { wd: WD[new Date(Date.UTC(a[0], a[1] - 1, a[2])).getUTCDay()], dm: a[2] + ' ' + MO[a[1] - 1] }; };
const dname = d => { const l = dlab(DAYS[d].date); return l.wd + ' ' + l.dm; };
const mins = e => Math.round((H(e.e) - H(e.s)) * 60);
const KEY = 'itin-' + TRIP.title;
const store = { get(k) { try { return localStorage.getItem(KEY + k); } catch (x) { return null; } }, set(k, v) { try { localStorage.setItem(KEY + k, v); } catch (x) { } } };

/* blocchi facoltativi dei dati: il file lite può non averli */
const VARS = typeof VARIANTS !== 'undefined' ? VARIANTS : [];
const RTS = typeof ROUTES !== 'undefined' ? ROUTES : {};
const BASEMAP = typeof BASE !== 'undefined' ? BASE : null;
const HAS_MAP = TRIP.map !== false && typeof L !== 'undefined';
const VIEWS = (TRIP.views || ['giorni', 'calendario', 'costi', 'info']);
const VLAB = { giorni: 'Giorni', calendario: 'Calendario', costi: 'Costi', info: 'Info' };

const TYPES = {
  visit: { label: 'Visita', v: '--c-visit', ic: 'visit' },
  meal: { label: 'Pasto', v: '--c-meal', ic: 'meal' },
  move: { label: 'Spostamento', v: '--c-move', ic: 'walk' },
  log: { label: 'Logistica', v: '--c-log', ic: 'clock' }
};
const MODES = {
  walk: { label: 'A piedi', short: '', ic: 'walk', g: 'walking' },
  metro: { label: 'Metropolitana', short: 'U', ic: 'metro', g: 'transit' },
  tram: { label: 'Tram', short: 'Tram', ic: 'metro', g: 'transit' },
  bus: { label: 'Autobus', short: 'Bus', ic: 'metro', g: 'transit' },
  train: { label: 'Treno', short: 'Treno', ic: 'train', g: 'transit' },
  taxi: { label: 'Taxi', short: 'Taxi', ic: 'pin', g: 'driving' },
  car: { label: 'Auto', short: 'Auto', ic: 'pin', g: 'driving' },
  ferry: { label: 'Traghetto', short: 'Nave', ic: 'train', g: 'transit' },
  plane: { label: 'Volo', short: 'Volo', ic: 'plane', g: '' }
};
const ST = { Confermato: '--st-conf', Prenotato: '--st-pren', Stima: '--st-stima', Ipotesi: '--st-ipo' };
const evIcon = e => e.type === 'move' ? MODES[e.mode].ic : (e.p && PLACES[e.p] && PLACES[e.p].kind === 'base' ? 'bed' : TYPES[e.type].ic);

/* ---- alternative: quale programma è attivo in ogni giorno ---- */
const act = {};
(function () { try { const s = JSON.parse(store.get('-var') || '{}'); Object.keys(s).forEach(d => { if (VARS.some(v => v.id === s[d] && v.d === +d)) act[d] = s[d]; }); } catch (x) { } })();
const inWin = (e, v) => H(e.s) >= (v.from ? H(v.from) : 0) && H(e.s) < (v.to ? H(v.to) : 24);
/* eventi di un giorno: quelli base, meno quelli che cadono nella finestra della variante attiva, più quelli della variante */
function dayEvents(d, vid) {
  const id = vid === undefined ? (act[d] || '') : vid, v = VARS.find(x => x.id === id);
  return EVENTS.filter(e => e.d === d && (e.v ? e.v === id : !(v && inWin(e, v)))).sort((a, b) => H(a.s) - H(b.s));
}
function costsFor(sel) {
  const A = sel || act, on = id => Object.keys(A).some(d => A[d] === id);
  return COSTS.filter(c => (c.v ? on(c.v) : true) && !(c.x && c.x.some(on)));
}
function setVar(d, id) { if (id) act[d] = id; else delete act[d]; store.set('-var', JSON.stringify(act)); refresh(); }
const SETS = Array.from(new Set(VARS.filter(v => v.set).map(v => v.set)));
function setScenario(s) { DAYS.forEach((x, d) => { const v = VARS.find(y => y.set === s && y.d === d); if (v) act[d] = v.id; else delete act[d]; }); store.set('-var', JSON.stringify(act)); refresh(); }
const curSet = () => SETS.find(s => DAYS.every((x, d) => { const v = VARS.find(y => y.set === s && y.d === d); return (act[d] || '') === (v ? v.id : ''); })) || (Object.keys(act).length ? null : '');

/* ---- geometria ---- */
function decode(str) {
  let i = 0, lat = 0, lng = 0; const out = [];
  while (i < str.length) {
    let b, s = 0, r = 0;
    do { b = str.charCodeAt(i++) - 63; r |= (b & 31) << s; s += 5; } while (b >= 32);
    lat += (r & 1) ? ~(r >> 1) : (r >> 1); s = 0; r = 0;
    do { b = str.charCodeAt(i++) - 63; r |= (b & 31) << s; s += 5; } while (b >= 32);
    lng += (r & 1) ? ~(r >> 1) : (r >> 1);
    out.push([lat / 1e5, lng / 1e5]);
  }
  return out;
}
function dist(a, b) {
  const R = 6371000, q = Math.PI / 180, x = (b[1] - a[1]) * q * Math.cos((a[0] + b[0]) / 2 * q), y = (b[0] - a[0]) * q;
  return Math.sqrt(x * x + y * y) * R;
}
/* divide una polyline nelle sue tratte: taglio alla distanza cumulata, poi aggancio al vertice più vicino alla tappa (se nota) */
function splitBy(pts, ms, snap) {
  const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + dist(pts[i - 1], pts[i]));
  const tot = ms.reduce((a, m) => a + m, 0), k = cum[cum.length - 1] / tot, cut = [0]; let acc = 0;
  for (let j = 0; j < ms.length - 1; j++) {
    acc += ms[j]; let best = cut[j], bd = 1e9;
    for (let i = cut[j]; i < pts.length; i++) { const dd = Math.abs(cum[i] - acc * k); if (dd < bd) { bd = dd; best = i; } }
    if (snap && snap[j + 1]) { const lo = Math.max(cut[j], best - 2), hi = Math.min(pts.length - 1, best + 2); let d2 = 1e9; for (let i = lo; i <= hi; i++) { const dd = dist(pts[i], snap[j + 1]); if (dd < d2) { d2 = dd; best = i; } } }
    cut.push(best);
  }
  cut.push(pts.length - 1);
  return ms.map((_, j) => pts.slice(cut[j], cut[j + 1] + 1));
}
const RG = {};
Object.keys(RTS).forEach(id => { const r = RTS[id]; RG[id] = splitBy(decode(r.poly), r.legs.map(l => l[0]), r.stops.map(s => [PLACES[s].lat, PLACES[s].lng])); });
/* alba e tramonto (formula NOAA semplificata), ore locali decimali */
function sun(iso) {
  const a = iso.split('-').map(Number), q = Math.PI / 180, lat = TRIP.center[0], lng = TRIP.center[1];
  const n = Math.floor((Date.UTC(a[0], a[1] - 1, a[2]) - Date.UTC(a[0], 0, 0)) / 864e5), g = 2 * Math.PI / 365 * (n - 1);
  const eq = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
  const de = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  const ha = Math.acos(Math.cos(90.833 * q) / (Math.cos(lat * q) * Math.cos(de)) - Math.tan(lat * q) * Math.tan(de)) / q;
  const noon = 720 - 4 * lng - eq;
  return [(noon - 4 * ha) / 60 + TRIP.utc, (noon + 4 * ha) / 60 + TRIP.utc];
}

/* ---- modello del giorno: tappe numerate, tratte e numeri di sintesi ---- */
function model(d, vid) {
  const evs = dayEvents(d, vid), stops = [], idx = {}, legs = [];
  const add = (id, e) => {
    if (!id || !PLACES[id]) return;
    let s = idx[id]; if (!s) { s = idx[id] = { id: id, evs: [] }; stops.push(s); }
    if (e) { s.evs.push(e); if (e.type === 'meal') s.meal = true; if (e.type === 'visit') s.visit = true; }
  };
  evs.forEach(e => { if (e.type === 'move') { add(e.from); add(e.to); legs.push(e); } else add(e.p, e); });
  let n = 0; stops.forEach(s => { if (PLACES[s.id].kind === 'poi') s.n = ++n; });
  let wm = 0, ws = 0, tr = 0, tmin = 0;
  legs.forEach(e => { if (e.r) { const l = RTS[e.r[0]].legs[e.r[1]]; wm += l[0]; ws += l[1]; } else if (e.mode === 'walk') ws += mins(e) * 60; else if (e.mode !== 'plane') { tr++; tmin += mins(e); } });
  const sel = Object.assign({}, act); if (vid !== undefined) { if (vid) sel[d] = vid; else delete sel[d]; }
  const cost = costsFor(sel).filter(c => c.d === d && c.amt != null).reduce((a, c) => a + c.amt, 0);
  return { evs: evs, stops: stops, legs: legs, idx: idx, n: n, wm: wm, ws: ws, tr: tr, tmin: tmin, cost: cost, end: evs.length ? evs[evs.length - 1].e : '' };
}
const legInfo = e => e.r ? { m: RTS[e.r[0]].legs[e.r[1]][0], min: Math.ceil(RTS[e.r[0]].legs[e.r[1]][1] / 60) } : { m: null, min: mins(e) };
const hasPos = p => p && typeof p.lat === 'number';
const gq = p => hasPos(p) && !(p.kind === 'poi' && p.q === 'C' && p.g) ? p.lat + ',' + p.lng : (p.g || p.addr || p.n);
const gSearch = p => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(p.g || p.addr || p.n);
const aSearch = p => 'https://maps.apple.com/?ll=' + p.lat + ',' + p.lng + '&q=' + encodeURIComponent(p.n);
const webSearch = p => 'https://www.google.com/search?q=' + encodeURIComponent(p.g || p.n);
const wikiLink = p => p.wiki || 'https://it.wikipedia.org/w/index.php?search=' + encodeURIComponent((p.g || p.n).split(',')[0]);
function gDir(ids, mode) {
  const P = ids.map(i => PLACES[i]);
  let u = 'https://www.google.com/maps/dir/?api=1&origin=' + encodeURIComponent(gq(P[0])) + '&destination=' + encodeURIComponent(gq(P[P.length - 1]));
  if (P.length > 2) u += '&waypoints=' + encodeURIComponent(P.slice(1, -1).map(gq).join('|'));
  return u + (mode ? '&travelmode=' + mode : '');
}

/* ---- mappa ---- */
let map, aLayer, gLayer, bLayer, dLayer, tilesOn = false, curDay = 0, pins = {}, fitAll = false;
const coarse = !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
function initMap() {
  /* sul telefono un dito scorre la pagina e due dita muovono la mappa: il pulsante sotto la mappa inverte la scelta */
  map = L.map('map', { zoomSnap: 0.25, minZoom: 10, maxZoom: 19, dragging: !coarse });
  map.attributionControl.setPrefix(false);
  map.attributionControl.addAttribution('Percorsi OSRM/FOSSGIS, dati © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>' + (BASEMAP && BASEMAP.credit ? ' - ' + esc(BASEMAP.credit) : ''));
  L.control.scale({ imperial: false }).addTo(map);
  aLayer = L.layerGroup().addTo(map); gLayer = L.layerGroup().addTo(map); bLayer = L.layerGroup().addTo(map); dLayer = L.layerGroup().addTo(map);
  if (BASEMAP) (BASEMAP.areas || []).forEach((a, i) => {
    L.polygon(decode(a.poly), { className: 'g-area a' + (i % 2), interactive: false }).addTo(aLayer);
    L.marker(a.at, { interactive: false, keyboard: false, zIndexOffset: -2000, icon: L.divIcon({ className: 'zlab', html: '<span>' + esc(a.n) + '</span>', iconSize: [0, 0] }) }).addTo(aLayer);
  });
  const c = TRIP.center, q = Math.PI / 180, dLat = 0.5 / 111.32, dLng = 0.5 / (111.32 * Math.cos(c[0] * q)), n = 26;
  for (let i = -n; i <= n; i++) {
    L.polyline([[c[0] + i * dLat, c[1] - n * dLng], [c[0] + i * dLat, c[1] + n * dLng]], { className: 'g-grid', interactive: false }).addTo(gLayer);
    L.polyline([[c[0] - n * dLat, c[1] + i * dLng], [c[0] + n * dLat, c[1] + i * dLng]], { className: 'g-grid', interactive: false }).addTo(gLayer);
  }
  let water = false;
  if (BASEMAP) (BASEMAP.lines || []).forEach(l => {
    const pts = decode(l.poly), segs = l.legs ? splitBy(pts, l.legs).map((p, i) => ({ n: l.names[i], pts: p })) : [{ n: l.n, pts: pts }];
    segs.forEach(s => {
      if (s.n === null) return;
      if (l.kind === 'water') water = true; else L.polyline(s.pts, { className: 'g-ctxc', interactive: false }).addTo(bLayer);
      const pl = L.polyline(s.pts, { className: l.kind === 'water' ? 'g-water' : 'g-ctx', interactive: false }).addTo(bLayer);
      if (s.n) pl.bindTooltip(s.n, { permanent: true, direction: 'center', className: 'ctxlab' + (l.kind === 'water' ? ' wlab' : '') });
    });
  });
  if (BASEMAP) (BASEMAP.labels || []).forEach(b => L.marker(b.at, { interactive: false, keyboard: false, zIndexOffset: -2000, icon: L.divIcon({ className: 'zlab plab', html: '<span>' + esc(b.n) + '</span>', iconSize: [0, 0] }) }).addTo(bLayer));
  $('#lgW').hidden = !water;
  map.on('zoomend', () => map.getContainer().classList.toggle('zfar', map.getZoom() < 13.5));
  if (coarse) { $('#dragBtn').hidden = false; $('#dragBtn').onclick = () => { if (map.dragging.enabled()) map.dragging.disable(); else map.dragging.enable(); dragLabel(); }; dragLabel(); }
  $('#fitBtn').onclick = () => { fitAll = !fitAll; drawDay(curDay); };
  setMode(false); tryTiles();
}
function dragLabel() { $('#dragBtn').textContent = map.dragging.enabled() ? 'Sposta con 1 dito: sì' : 'Sposta con 1 dito: no'; }
function setMode(on) {
  tilesOn = on;
  [aLayer, gLayer, bLayer].forEach(l => { if (on) map.removeLayer(l); else if (!map.hasLayer(l)) l.addTo(map); });
  if (!on && map.hasLayer(dLayer)) { map.removeLayer(dLayer); dLayer.addTo(map); }
  $('#mapMode').innerHTML = on ? '<b>Cartografia</b> OpenStreetMap' : '<b>Mappa schematica</b> - ' + (BASEMAP ? esc(BASEMAP.desc || 'riferimenti principali') + ', ' : '') + 'griglia 500 m, nord in alto';
  if (map._loaded) drawDay(curDay, true);
}
/* la cartografia a tessere è un di più: si prova una tessera, se non arriva si resta in schematico */
function tryTiles() {
  const t = TRIP.tiles || {}; let url = '', att = '';
  if (t.cartoKey) { url = 'https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png?key=' + encodeURIComponent(t.cartoKey); att = '© OpenStreetMap contributors, © <a href="https://carto.com/attribution/" target="_blank" rel="noopener">CARTO</a>'; }
  else if (t.osm && /^https?:$/.test(location.protocol)) { url = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'; att = 'Mappa © OpenStreetMap contributors'; }
  if (!url) return;
  const z = 13, q = Math.PI / 180, c = TRIP.center, x = Math.floor((c[1] + 180) / 360 * (1 << z)),
    y = Math.floor((1 - Math.log(Math.tan(c[0] * q) + 1 / Math.cos(c[0] * q)) / Math.PI) / 2 * (1 << z));
  const im = new Image(); let done = false;
  im.referrerPolicy = 'strict-origin-when-cross-origin';
  im.onload = () => { if (done) return; done = true; L.tileLayer(url, { attribution: att, maxZoom: 19, referrerPolicy: 'strict-origin-when-cross-origin' }).addTo(map); setMode(true); };
  im.onerror = () => { done = true; };
  setTimeout(() => { done = true; }, 6000);
  im.src = url.replace('{z}', z).replace('{x}', x).replace('{y}', y);
}
function drawDay(d, keepView) {
  if (!map) return;
  curDay = d; dLayer.clearLayers(); pins = {};
  const m = model(d), B = [];
  m.legs.forEach(e => {
    const a = PLACES[e.from], b = PLACES[e.to]; if (!hasPos(a) || !hasPos(b)) return;
    const li = legInfo(e); let line;
    if (e.r) { const pts = RG[e.r[0]][e.r[1]]; L.polyline(pts, { className: 'g-case', interactive: false }).addTo(dLayer); line = L.polyline(pts, { className: 'g-walk' }); }
    else line = L.polyline([[a.lat, a.lng], [b.lat, b.lng]], { className: 'g-tr' });
    line.addTo(dLayer).on('click', () => openEvent(e));
    if (!a.far && !b.far) line.bindTooltip((MODES[e.mode].short ? MODES[e.mode].short + ' ' : '') + li.min + "'", { permanent: true, direction: 'center', className: 'leglab' });
  });
  m.stops.forEach(s => {
    const p = PLACES[s.id]; if (!hasPos(p)) return;
    const cls = p.kind !== 'poi' ? 'log' : (s.meal && !s.visit ? 'meal' : 'visit');
    const inner = p.kind === 'base' ? icon('bed') : p.kind === 'hub' ? icon(p.ic || 'train') : s.n;
    const mk = L.marker([p.lat, p.lng], { title: p.n, alt: p.n, icon: L.divIcon({ className: '', html: '<div class="pin ' + cls + (p.q === 'C' ? ' qc' : '') + '">' + inner + '</div>', iconSize: [28, 28], iconAnchor: [14, 14] }) });
    mk.addTo(dLayer).on('click', () => openPlace(s.id, d));
    pins[s.id] = mk; if (!p.far) B.push(p);
  });
  if (keepView) return;
  /* inquadratura: prima le tappe; alloggio e snodi entrano solo se non allargano troppo la vista */
  const ll = p => [p.lat, p.lng], dg = b => dist([b.getSouth(), b.getWest()], [b.getNorth(), b.getEast()]);
  let core = B.filter(p => p.kind === 'poi'); if (fitAll || core.length < 2) core = B;
  if (!core.length) { map.setView(TRIP.center, 14, { animate: false }); return; }
  let bb = L.latLngBounds(core.map(ll)); const d0 = Math.max(dg(bb), 400);
  B.forEach(p => { const b2 = L.latLngBounds(bb.getSouthWest(), bb.getNorthEast()).extend(ll(p)); if (dg(b2) <= d0 * 1.6) bb = b2; });
  $('#fitBtn').hidden = B.every(p => bb.contains(ll(p))) && !fitAll;
  $('#fitBtn').textContent = fitAll ? 'Solo le tappe' : 'Inquadra tutto';
  if (core.length > 1) map.fitBounds(bb.pad(0.16), { animate: false }); else map.setView(ll(core[0]), 15, { animate: false });
  map.getContainer().classList.toggle('zfar', map.getZoom() < 13.5);
}
function focusPin(id) {
  if (!map) return;
  Object.keys(pins).forEach(k => { const el = pins[k].getElement(); if (el) el.firstChild.classList.toggle('on', k === id); });
  const p = PLACES[id]; if (p && !p.far && pins[id]) map.panTo([p.lat, p.lng]);
}

/* ---- vista Giorni ---- */
function renderDayNav() {
  $('#dayNav').innerHTML = DAYS.map((x, i) => '<button type="button" data-d="' + i + '" aria-pressed="' + (i === curDay) + '"><b>' + dname(i) + (act[i] ? '<i title="variante attiva"></i>' : '') + '</b><span>' + esc(x.title) + '</span></button>').join('');
  const sb = $('#setBox'); sb.hidden = !SETS.length;
  if (SETS.length) { const cs = curSet(); sb.innerHTML = '<span class="lab">Scenario</span><button type="button" data-set="" aria-pressed="' + (cs === '') + '">Base</button>' + SETS.map(s => '<button type="button" data-set="' + esc(s) + '" aria-pressed="' + (cs === s) + '">' + esc(s) + '</button>').join(''); }
}
function renderVars(d) {
  const vs = VARS.filter(v => v.d === d), box = $('#varBox'); box.hidden = !vs.length; if (!vs.length) return;
  const cur = act[d] || '';
  $('#varSeg').innerHTML = '<span class="lab">Programma</span><button type="button" data-v="" aria-pressed="' + (cur === '') + '">Base</button>' +
    vs.map(v => '<button type="button" data-v="' + esc(v.id) + '" aria-pressed="' + (cur === v.id) + '">' + esc(v.short || v.name) + '</button>').join('');
  const v = vs.find(x => x.id === cur);
  $('#varNote').innerHTML = v ? '<b>' + esc(v.name) + '</b>' + (v.from ? ' (' + v.from + ' - ' + (v.to || 'fine giornata') + ')' : '') + '. ' + esc(v.why || '') + (v.pro ? ' <b>Pro:</b> ' + esc(v.pro) + '.' : '') + (v.contro ? ' <b>Contro:</b> ' + esc(v.contro) + '.' : '')
    : 'Programma base. ' + (vs.length === 1 ? 'È disponibile una alternativa' : 'Sono disponibili ' + vs.length + ' alternative') + ' per questo giorno: la scelta vale per mappa, calendario e costi.';
  const row = (id, name) => { const m = model(d, id); return '<tr class="' + (id === cur ? 'on' : '') + '"><td>' + esc(name) + '<small>' + m.n + ' tappe - fine ' + m.end + '</small></td><td class="n">' + dec(m.wm / 1000, 1) + ' km<small>' + Math.round(m.ws / 60) + ' min</small></td><td class="n">' + m.tmin + ' min<small>' + m.tr + (m.tr === 1 ? ' tratta' : ' tratte') + '</small></td><td class="n">' + euro(m.cost) + '</td></tr>'; };
  $('#varTbl').innerHTML = '<thead><tr><th>Programma</th><th class="n">A piedi</th><th class="n">Mezzi</th><th class="n">Spesa</th></tr></thead><tbody>' + row('', 'Base') + vs.map(v => row(v.id, v.short || v.name)).join('') + '</tbody>';
}
function renderDay(d) {
  fitAll = false; curDay = d; store.set('-day', String(d)); renderDayNav(); renderVars(d);
  const m = model(d), sn = sun(DAYS[d].date);
  $('#dayStats').innerHTML =
    (m.ws ? '<span class="stat">' + icon('walk') + ' <b>' + (m.wm ? dec(m.wm / 1000, 1) + ' km</b> - ' : '</b>') + Math.round(m.ws / 60) + ' min a piedi</span>' : '') +
    (m.tr ? '<span class="stat">' + icon('metro') + ' <b>' + m.tr + '</b> ' + (m.tr === 1 ? 'tratta' : 'tratte') + ' con i mezzi - ' + m.tmin + ' min</span>' : '') +
    '<span class="stat">Spesa del giorno <b>' + euro(m.cost) + '</b></span>' +
    '<span class="stat">Luce ' + fmtH(sn[0]) + ' - ' + fmtH(sn[1]) + '</span>';
  $('#agenda').innerHTML = m.evs.map((e, i) => {
    const p = e.p && PLACES[e.p], alt = e.v ? '<span class="chip alt">variante</span>' : '';
    if (e.type === 'move') {
      const li = legInfo(e), md = MODES[e.mode];
      return '<li class="t-move"><span class="ag-time">' + e.s + '</span><span class="ag-rail"><span class="dot"></span></span><button type="button" class="ag-body" data-i="' + i + '">' +
        icon(md.ic) + '<span>' + esc(e.title) + '</span><span class="chip">' + li.min + ' min' + (li.m ? ' - ' + dec(li.m / 1000, 1) + ' km' : '') + '</span>' + (e.r ? '' : '<span class="chip">stima</span>') + alt + '</button></li>';
    }
    const dot = p && p.kind === 'poi' && m.idx[e.p] && m.idx[e.p].n ? m.idx[e.p].n : icon(evIcon(e));
    const sub = e.s + ' - ' + e.e + (p && p.addr ? ' - ' + esc(p.addr.split(',')[0]) : '');
    return '<li class="t-' + e.type + '"><span class="ag-time">' + e.s + '</span><span class="ag-rail"><span class="dot">' + dot + '</span></span><button type="button" class="ag-body" data-i="' + i + '"><b>' + esc(e.title) + '</b><small>' + sub + '</small>' +
      (p && p.q === 'C' && p.kind === 'poi' && HAS_MAP ? '<span class="chip warn">posizione approssimata</span> ' : '') + alt + '</button></li>';
  }).join('');
  $('#agenda').onclick = ev => { const b = ev.target.closest('button[data-i]'); if (!b) return; const e = m.evs[+b.dataset.i]; if (e.type !== 'move' && e.p && PLACES[e.p]) openPlace(e.p, d, e); else openEvent(e); };
  /* collegamenti al navigatore: un link per ogni catena a piedi usata oggi, al massimo 3 tappe intermedie per link */
  const used = []; m.legs.forEach(e => { if (e.r && used.indexOf(e.r[0]) < 0) used.push(e.r[0]); });
  let links = '';
  used.forEach(id => {
    const st = RTS[id].stops;
    for (let i = 0; i < st.length - 1; i += 4) {
      const seg = st.slice(i, Math.min(i + 5, st.length)); if (seg.length < 2) break;
      links += ext(gDir(seg, 'walking'), icon('ext') + ' ' + esc(PLACES[seg[0]].n.split(' - ')[0]) + ' → ' + esc(PLACES[seg[seg.length - 1]].n.split(' - ')[0]) + ' in Google Maps');
    }
  });
  $('#dayLinks').innerHTML = links; $('#dayLinks').hidden = !links;
  drawDay(d);
}

/* ---- scheda di dettaglio ---- */
let lastFocus = null;
function sheet(tag, color, title, when, text, facts, links) {
  $('#sTag').textContent = tag; $('#sTag').style.background = 'var(' + color + ')';
  $('#sTitle').textContent = title; $('#sWhen').textContent = when || ''; $('#sText').textContent = text || ''; $('#sText').hidden = !text;
  $('#sFacts').innerHTML = facts.filter(f => f[1]).map(f => '<dt>' + f[0] + '</dt><dd>' + esc(f[1]) + '</dd>').join('');
  $('#sLinks').innerHTML = links.join('');
  lastFocus = document.activeElement; $('#overlay').hidden = false; $('#sClose').focus();
}
function closeSheet() { $('#overlay').hidden = true; if (lastFocus && lastFocus.focus) lastFocus.focus(); }
function openPlace(id, d, ev) {
  const p = PLACES[id], m = model(d), s = m.idx[id], evs = ev ? [ev] : (s ? s.evs : []);
  const t = p.kind === 'poi' ? (s && s.meal && !s.visit ? 'meal' : 'visit') : 'log';
  const when = evs.map(e => dlab(DAYS[d].date).wd + ' ' + e.s + ' - ' + e.e + ' ' + e.title).join('\n');
  const txt = [p.note].concat(evs.map(e => e.detail)).filter(Boolean).join('\n\n');
  /* i collegamenti cercano nome e indirizzo: portano al posto giusto anche se la posizione in mappa è approssimata */
  const links = [ext(gSearch(p), icon('pin') + ' Google Maps', 'pri')];
  if (hasPos(p)) links.push(ext(aSearch(p), icon('pin') + ' Apple Maps'));
  if (p.kind === 'poi') { links.push(ext(webSearch(p), icon('find') + ' Google')); links.push(ext(wikiLink(p), icon('find') + ' Wikipedia')); }
  if (p.web) links.push(ext(p.web, icon('ext') + ' Sito'));
  sheet(p.kind === 'poi' ? (s && s.n ? 'Tappa ' + s.n : TYPES[t].label) : (p.kind === 'base' ? 'Alloggio' : 'Snodo'), TYPES[t].v, p.n, when, txt,
    [['Indirizzo', p.addr], ['Orari', p.hours], ['Prezzo', p.price], ['Posizione', p.q ? 'classe ' + p.q + ' - ' + p.src : '']], links);
  if (d === curDay && !$('#v-giorni').hidden) focusPin(id);
}
function openEvent(e) {
  const d = e.d, a = PLACES[e.from], b = PLACES[e.to], facts = [], links = [];
  let txt = e.detail || '';
  if (e.type === 'move') {
    if (e.r) { const li = legInfo(e); txt = 'Percorso calcolato su strade reali: ' + dec(li.m, 0) + ' m, ' + li.min + ' minuti a circa 4,5 km/h. In calendario ' + mins(e) + ' minuti.' + (txt ? '\n\n' + txt : ''); }
    facts.push(['Mezzo', MODES[e.mode].label], ['Da', a && a.n], ['A', b && b.n]);
    if (a && b && MODES[e.mode].g) links.push(ext(gDir([e.from, e.to], MODES[e.mode].g), icon('ext') + ' Indicazioni in Google Maps', 'pri'));
  }
  sheet((e.v ? 'Variante - ' : '') + (e.type === 'move' ? MODES[e.mode].label : TYPES[e.type].label), TYPES[e.type].v, e.title, dname(d) + ', ' + e.s + ' - ' + e.e + ' (' + mins(e) + ' min)', txt, facts, links);
}

/* ---- calendario ---- */
let CAL = [];
function buildCal() {
  const h0 = TRIP.hours[0], h1 = TRIP.hours[1], cal = $('#cal'); CAL = [];
  cal.style.gridTemplateColumns = '44px repeat(' + DAYS.length + ', minmax(100px, 1fr))'; cal.style.minWidth = (44 + DAYS.length * 100) + 'px';
  let h = '<div class="corner"></div>' + DAYS.map((x, d) => {
    const vs = VARS.filter(v => v.d === d);
    return '<div class="ch"><b>' + dname(d) + '</b><small>' + esc(x.title) + '</small>' + (vs.length ? '<select data-vd="' + d + '" aria-label="Programma di ' + dname(d) + '"><option value="">Base</option>' + vs.map(v => '<option value="' + esc(v.id) + '"' + (act[d] === v.id ? ' selected' : '') + '>' + esc(v.short || v.name) + '</option>').join('') + '</select>' : '') + '</div>';
  }).join('');
  h += '<div class="times">'; for (let i = h0; i < h1; i++) h += '<div>' + String(i).padStart(2, '0') + ':00</div>'; h += '</div>';
  DAYS.forEach((x, d) => {
    const sn = sun(x.date), top = v => 'calc(' + (v - h0).toFixed(3) + ' * var(--hour-h))';
    h += '<div class="col" style="height:calc(' + (h1 - h0) + ' * var(--hour-h))">' +
      '<div class="night" style="top:0;height:' + top(sn[0]) + '"></div><div class="night" style="top:' + top(sn[1]) + ';bottom:0"></div>' +
      '<div class="sunline" style="top:' + top(sn[0]) + '"></div><div class="sunline" style="top:' + top(sn[1]) + '"></div>';
    dayEvents(d).forEach(e => {
      const i = CAL.push(e) - 1, s = H(e.s), du = H(e.e) - s, cls = (du < 0.25 ? ' bar' : du < 0.6 ? ' xs' : '') + (e.v ? ' alt' : '');
      h += '<button type="button" class="ev t-' + e.type + cls + '" data-i="' + i + '" aria-label="' + esc(e.s + ' ' + e.title) + '" style="top:calc(' + (s - h0).toFixed(3) + ' * var(--hour-h) + 1px);height:calc(' + du.toFixed(3) + ' * var(--hour-h) - 2px)">' +
        (du < 0.25 ? '' : '<b>' + icon(evIcon(e)) + ' ' + esc(e.title) + '</b>' + (du < 0.6 ? '' : '<span>' + e.s + ' - ' + e.e + '</span>')) + '</button>';
    });
    h += '</div>';
  });
  cal.innerHTML = h;
  cal.onclick = ev => { const b = ev.target.closest('button[data-i]'); if (!b) return; const e = CAL[+b.dataset.i]; if (e.type !== 'move' && e.p && PLACES[e.p]) openPlace(e.p, e.d, e); else openEvent(e); };
  cal.onchange = ev => { const s = ev.target.closest('select[data-vd]'); if (s) setVar(+s.dataset.vd, s.value); };
  const sn = sun(DAYS[0].date);
  $('#calKeys').innerHTML = Object.keys(TYPES).map(k => '<span><i style="background:var(' + TYPES[k].v + ')"></i>' + TYPES[k].label + '</span>').join('') +
    (VARS.length ? '<span><i style="background:none;outline:2px dashed var(--gold);outline-offset:-2px"></i>variante attiva</span>' : '') +
    '<span><i style="background:none;border-top:2px dashed var(--gold);border-radius:0;height:0;vertical-align:3px"></i>alba ' + fmtH(sn[0]) + ', tramonto ' + fmtH(sn[1]) + '</span>';
}
let hourH = 46;
function zoom(k) { hourH = Math.max(30, Math.min(110, hourH + k)); document.documentElement.style.setProperty('--hour-h', hourH + 'px'); }

/* ---- costi ---- */
function fill(sel, first, vals) { const cur = sel.value; sel.innerHTML = '<option value="">' + first + '</option>' + vals.map(v => '<option value="' + esc(v[0]) + '">' + esc(v[1]) + '</option>').join(''); sel.value = cur; }
const sdot = st => '<span class="sdot" style="background:var(' + ST[st] + ')"></span>';
function renderCosts() {
  const all = costsFor(), fc = $('#fCat').value, fd = $('#fDay').value, fs = $('#fSt').value, fq = $('#fQ').value.trim().toLowerCase();
  const rows = all.filter(c => (!fc || c.cat === fc) && (fd === '' || c.d === +fd) && (!fs || c.st === fs) && (!fq || (c.desc + ' ' + (c.note || '') + ' ' + c.cat).toLowerCase().indexOf(fq) >= 0));
  const sum = a => a.reduce((t, c) => t + (c.amt || 0), 0), tot = sum(rows), open = rows.filter(c => c.amt == null).length;
  const by = st => sum(rows.filter(c => c.st === st)), solid = by('Confermato') + by('Prenotato') + by('Stima');
  const on = Object.keys(act).map(d => dname(+d) + ': ' + (VARS.find(v => v.id === act[d]) || {}).name);
  $('#costVar').hidden = !on.length; $('#costVar').innerHTML = on.length ? '<b>Costi calcolati con le varianti attive</b> - ' + esc(on.join('; ')) + '.' : '';
  $('#costTiles').innerHTML =
    '<div class="card tile"><small>Totale' + (rows.length < all.length ? ' filtrato' : ' del viaggio') + '</small><div class="v">' + euro(tot) + '</div>' +
    '<div class="sbar">' + Object.keys(ST).map(s => '<i style="width:' + (tot ? by(s) / tot * 100 : 0) + '%;background:var(' + ST[s] + ')"></i>').join('') + '</div>' +
    '<div class="skeys">' + Object.keys(ST).filter(s => by(s)).map(s => '<span>' + sdot(s) + s + ' ' + euro(by(s)) + '</span>').join('') + '</div></div>' +
    '<div class="card tile"><small>Con prezzo da fonte o pagato</small><div class="v">' + euro(solid) + '</div><small>' + (tot ? Math.round(solid / tot * 100) : 0) + '% del totale</small></div>' +
    '<div class="card tile"><small>Ipotesi da sostituire</small><div class="v">' + euro(by('Ipotesi')) + '</div><small>' + (open ? open + (open === 1 ? ' voce' : ' voci') + ' senza importo, fuori dal totale' : 'tutte le voci hanno un importo') + '</small></div>';
  $('#tCost').innerHTML = '<thead><tr><th>Voce</th><th>Stato</th><th class="n">Importo</th></tr></thead><tbody>' +
    rows.map(c => '<tr><td>' + esc(c.desc) + (c.v ? ' <span class="chip alt">variante</span>' : '') + '<small>' + dname(c.d) + ' - ' + esc(c.cat) + (c.note ? ' - ' + esc(c.note) : '') + '</small></td><td style="white-space:nowrap">' + sdot(c.st) + c.st + '</td><td class="n">' + (c.amt == null ? '<span class="tbd">da definire</span>' : euro(c.amt)) + '</td></tr>').join('') +
    (rows.length ? '' : '<tr><td colspan="3">Nessuna voce con questi filtri.</td></tr>') +
    '</tbody><tfoot><tr><td colspan="2">Totale</td><td class="n">' + euro(tot) + '</td></tr></tfoot>';
  const grp = (key, lab) => { const g = {}; rows.forEach(c => { const k = key(c); g[k] = (g[k] || 0) + (c.amt || 0); }); return Object.keys(g).sort(lab ? (a, b) => a - b : (a, b) => g[b] - g[a]).map(k => '<tr><td>' + esc(lab ? lab(k) : k) + '</td><td class="n">' + euro(g[k]) + '</td><td class="n">' + (tot ? Math.round(g[k] / tot * 100) : 0) + '%</td></tr>').join(''); };
  const foot = '<tfoot><tr><td>Totale</td><td class="n">' + euro(tot) + '</td><td></td></tr></tfoot>';
  $('#tCat').innerHTML = '<tbody>' + grp(c => c.cat) + '</tbody>' + foot;
  $('#tDay').innerHTML = '<tbody>' + grp(c => c.d, k => dname(+k)) + '</tbody>' + foot;
}
function initCosts() {
  fill($('#fCat'), 'Tutte', Array.from(new Set(COSTS.map(c => c.cat))).map(v => [v, v]));
  fill($('#fDay'), 'Tutti', DAYS.map((x, i) => [i, dname(i)]));
  fill($('#fSt'), 'Tutti', Array.from(new Set(COSTS.map(c => c.st))).map(v => [v, v]));
  ['fCat', 'fDay', 'fSt'].forEach(id => $('#' + id).onchange = renderCosts); $('#fQ').oninput = renderCosts;
  $('#fReset').onclick = () => { ['fCat', 'fDay', 'fSt', 'fQ'].forEach(id => $('#' + id).value = ''); renderCosts(); };
}

/* ---- info ---- */
function renderInfo() {
  const card = (t, body) => '<div class="card"><p class="card-t">' + t + '</p>' + body + '</div>';
  const light = DAYS.map((x, d) => { const s = sun(x.date); return '<li>' + dname(d) + ': alba ' + fmtH(s[0]) + ', tramonto ' + fmtH(s[1]) + '</li>'; }).join('');
  const alts = VARS.map(v => '<li><b>' + dname(v.d) + ' - ' + esc(v.name) + '</b>' + (v.from ? ' (' + v.from + ' - ' + (v.to || 'fine') + ')' : '') + ': ' + esc(v.why || '') + '</li>').join('');
  $('#v-info').innerHTML =
    (typeof INFO !== 'undefined' ? INFO : []).map(c => card(esc(c.t), '<ul>' + c.items.map(i => '<li>' + esc(i) + '</li>').join('') + '</ul>')).join('') +
    (alts ? card('Alternative pronte', '<ul>' + alts + '<li>Si attivano dal selettore Programma nella vista Giorni o dal menu sopra la colonna del calendario.</li></ul>') : '') +
    card('Luce', '<ul>' + light + '<li>Orari calcolati per il centro città: sono le linee tratteggiate del calendario.</li></ul>') +
    (typeof TODO !== 'undefined' && TODO.length ? card('Da verificare o prenotare', '<ul class="todo">' + TODO.map(t => '<li><span>' + esc(t) + '</span></li>').join('') + '</ul>') : '') +
    (typeof FONTI !== 'undefined' && FONTI.length ? card('Fonti - verifica del ' + esc(TRIP.verified), '<ul>' + FONTI.map(f => '<li><a href="' + esc(f[1]) + '" target="_blank" rel="noopener">' + esc(f[0]) + '</a></li>').join('') + '</ul>') : '');
}

/* ---- intestazione, navigazione, aggiornamento ---- */
function renderHead() {
  const seen = {}; let walk = 0;
  DAYS.forEach((x, d) => { const m = model(d); walk += m.wm; m.stops.forEach(s => { if (PLACES[s.id].kind === 'poi') seen[s.id] = 1; }); });
  const tot = costsFor().reduce((a, c) => a + (c.amt || 0), 0), np = Object.keys(seen).length;
  $('#hTitle').textContent = TRIP.title; $('#hSub').textContent = TRIP.sub;
  $('#hKpi').innerHTML = '<span class="kpi"><b>' + DAYS.length + '</b> giorni</span>' + (np ? '<span class="kpi"><b>' + np + '</b> luoghi</span>' : '') + (walk ? '<span class="kpi"><b>' + dec(walk / 1000, 1) + ' km</b> a piedi</span>' : '') +
    '<span class="kpi">Totale stimato <b>' + euro(tot) + '</b></span>' + (Object.keys(act).length ? '<span class="kpi">con <b>' + Object.keys(act).length + '</b> ' + (Object.keys(act).length === 1 ? 'variante attiva' : 'varianti attive') + '</span>' : '');
}
function refresh() { renderHead(); if (VIEWS.indexOf('giorni') >= 0) renderDay(curDay); if (VIEWS.indexOf('calendario') >= 0) buildCal(); if (VIEWS.indexOf('costi') >= 0) renderCosts(); }
function show(tab, push) {
  if (VIEWS.indexOf(tab) < 0) tab = VIEWS[0];
  ['giorni', 'calendario', 'costi', 'info'].forEach(t => { $('#v-' + t).hidden = t !== tab; });
  document.querySelectorAll('#tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === tab));
  if (tab === 'giorni' && map) { map.invalidateSize(); drawDay(curDay); }
  if (push) { try { location.hash = tab; } catch (x) { } }
}

/* ---- avvio ---- */
(function () {
  $('#tabs').innerHTML = VIEWS.map(t => '<button type="button" role="tab" data-tab="' + t + '" aria-selected="false">' + VLAB[t] + '</button>').join('');
  $('#tabs').hidden = VIEWS.length < 2;
  const sd = +store.get('-day'); curDay = sd >= 0 && sd < DAYS.length ? sd : 0;
  $('#mapCard').hidden = !HAS_MAP; $('#dayGrid').classList.toggle('withmap', HAS_MAP);
  show(location.hash.slice(1));                     /* la vista deve essere visibile prima di creare la mappa */
  if (HAS_MAP && VIEWS.indexOf('giorni') >= 0) initMap();
  if (VIEWS.indexOf('costi') >= 0) initCosts();
  refresh(); if (VIEWS.indexOf('info') >= 0) renderInfo();
  $('#dayNav').onclick = ev => { const b = ev.target.closest('button[data-d]'); if (b) renderDay(+b.dataset.d); };
  $('#varSeg').onclick = ev => { const b = ev.target.closest('button[data-v]'); if (b) setVar(curDay, b.dataset.v); };
  $('#setBox').onclick = ev => { const b = ev.target.closest('button[data-set]'); if (b) setScenario(b.dataset.set); };
  $('#tabs').onclick = ev => { const b = ev.target.closest('button[data-tab]'); if (b) show(b.dataset.tab, true); };
  $('#zIn').onclick = () => zoom(10); $('#zOut').onclick = () => zoom(-10);
  $('#sClose').onclick = closeSheet; $('#overlay').onclick = ev => { if (ev.target.id === 'overlay') closeSheet(); };
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape' && !$('#overlay').hidden) closeSheet(); });
  window.addEventListener('hashchange', () => show(location.hash.slice(1)));
})();
