/* Aree di contesto da un GeoJSON di quartieri: node base-areas.mjs quartieri.geojson data.js [km]
   Tiene i poligoni che toccano il riquadro dei luoghi non lontani (allargato di [km], predefinito 1.5),
   li semplifica a circa 12 m e stampa l'array "areas" da incollare in BASE. */
import fs from 'fs';
import polyline from '@mapbox/polyline';
const g = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const D = new Function(fs.readFileSync(process.argv[3], 'utf8') + '; return {PLACES,TRIP};')();
const pad = +(process.argv[4] || 1.5), P = Object.values(D.PLACES).filter(p => !p.far && p.lat);
const q = Math.PI / 180, kLat = 111.32, kLng = 111.32 * Math.cos(D.TRIP.center[0] * q);
const bb = [Math.min(...P.map(p => p.lat)) - pad / kLat, Math.min(...P.map(p => p.lng)) - pad / kLng, Math.max(...P.map(p => p.lat)) + pad / kLat, Math.max(...P.map(p => p.lng)) + pad / kLng];
const xy = c => [(c[0] - D.TRIP.center[1]) * kLng * 1000, (c[1] - D.TRIP.center[0]) * kLat * 1000];
function dp(pts, tol) { if (pts.length < 3) return pts; const a = xy(pts[0]), b = xy(pts[pts.length - 1]); let mx = 0, ix = 0; const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1e-9;
  for (let i = 1; i < pts.length - 1; i++) { const p = xy(pts[i]), d = Math.abs(dy * (p[0] - a[0]) - dx * (p[1] - a[1])) / L; if (d > mx) { mx = d; ix = i; } }
  return mx > tol ? dp(pts.slice(0, ix + 1), tol).slice(0, -1).concat(dp(pts.slice(ix), tol)) : [pts[0], pts[pts.length - 1]]; }
const out = [];
for (const f of g.features) {
  const polys = f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates;
  let ring = polys.map(p => p[0]).sort((a, b) => b.length - a.length)[0];            // anello esterno più grande
  const la = ring.map(c => c[1]), lo = ring.map(c => c[0]);
  if (Math.max(...la) < bb[0] || Math.min(...la) > bb[2] || Math.max(...lo) < bb[1] || Math.min(...lo) > bb[3]) continue;
  const half = Math.floor(ring.length / 2), s = dp(ring.slice(0, half + 1), 12).slice(0, -1).concat(dp(ring.slice(half), 12));
  let A = 0, cx = 0, cy = 0; for (let i = 0; i < s.length - 1; i++) { const k = s[i][0] * s[i + 1][1] - s[i + 1][0] * s[i][1]; A += k; cx += (s[i][0] + s[i + 1][0]) * k; cy += (s[i][1] + s[i + 1][1]) * k; }
  out.push({ n: f.properties.name || f.properties.NAME || '?', at: [+(cy / (3 * A)).toFixed(5), +(cx / (3 * A)).toFixed(5)], poly: polyline.encode(s.map(c => [c[1], c[0]])), pts: s.length });
}
console.error(out.map(a => a.n + ' ' + a.pts).join(' | '));
console.log(JSON.stringify(out.map(({ pts, ...a }) => a)));
