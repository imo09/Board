/* Costruzione: node build.mjs [data.js] [uscita.html]
   Unisce template.html + data.js + app.js. Leaflet entra solo se TRIP.map non è false (versione lite senza mappa). */
import fs from 'fs';
const r = f => fs.readFileSync(f, 'utf8');
const dataFile = process.argv[2] || 'data.js', outFile = process.argv[3] || 'itinerario.html';
const data = r(dataFile), app = r('app.js');
const TRIP = new Function(data + '; return TRIP;')();
const lite = TRIP.map === false;
let css = '', js = '';
if (!lite) {
  css = r('node_modules/leaflet/dist/leaflet.css').replace(/url\([^)]*\)/g, 'none');   // niente immagini esterne: si usano solo divIcon
  js = r('node_modules/leaflet/dist/leaflet.js').replace(/\/\/# sourceMappingURL=.*$/m, '');
  if (/<\/script/i.test(js)) throw new Error('leaflet contiene </script>');
}
if (/<\/script/i.test(data + app)) throw new Error('i dati o la logica contengono </script>');
let out = r('template.html');
const put = (k, v) => { if (out.split(k).length !== 2) throw new Error('segnaposto ' + k); out = out.split(k).join(v); };
put('__TITLE__', TRIP.title); put('__LEAFLET_CSS__', css); put('__LEAFLET_JS__', js); put('__DATA__', data); put('__APP__', app);
fs.writeFileSync(outFile, out);
console.log((lite ? 'lite' : 'completo') + ' ok', (out.length / 1024).toFixed(0) + ' KB', outFile);
