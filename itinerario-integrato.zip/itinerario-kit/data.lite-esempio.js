/* Esempio di PRIMA BOZZA LITE: solo calendario e costi, nessuna coordinata, nessun percorso calcolato.
   Costa pochissimo: serve a decidere struttura dei giorni e ordine di grandezza della spesa.
   Per passare alla versione con mappa si aggiungono lat, lng, q, src ai luoghi, i blocchi ROUTES e BASE, e si mette map: true. */
const TRIP = {
  title: "Vienna - prima bozza",
  sub: "Ven 11 - Dom 13 dicembre 2026 - 1 persona - bozza lite, tutto da verificare",
  verified: "nessuna verifica: bozza",
  center: [48.2082, 16.3738],
  utc: 1,
  hours: [8, 22],
  map: false,
  views: ["calendario", "costi", "info"]
};

const DAYS = [
  { date: "2026-12-11", title: "Arrivo e centro", sleep: "Vienna" },
  { date: "2026-12-12", title: "Wienzeile e Neubau", sleep: "Vienna" },
  { date: "2026-12-13", title: "Prater e rientro", sleep: "Roma" }
];

/* Nella bozza lite i luoghi hanno solo nome, testo di ricerca e indirizzo: bastano per i collegamenti al navigatore */
const PLACES = {
  lodging: { n: "Alloggio (zona Neubau)", kind: "base", addr: "Zona Neubaugasse, 1070 Wien" },
  stephansdom: { n: "Stephansdom", g: "Stephansdom, Wien", kind: "poi", addr: "Stephansplatz 3, 1010 Wien" },
  secession: { n: "Secession", g: "Secession, Friedrichstraße 12, Wien", kind: "poi", addr: "Friedrichstraße 12, 1010 Wien" },
  westlicht: { n: "WestLicht", g: "WestLicht, Westbahnstraße 40, Wien", kind: "poi", addr: "Westbahnstraße 40, 1070 Wien" },
  riesenrad: { n: "Riesenrad", g: "Wiener Riesenrad, Wien", kind: "poi", addr: "Riesenradplatz 1, 1020 Wien" }
};

const EVENTS = [
  { d: 0, s: "08:30", e: "10:10", type: "move", mode: "plane", title: "Volo Roma - Vienna", detail: "IPOTESI - Volo del mattino, da scegliere." },
  { d: 0, s: "10:30", e: "12:00", type: "move", mode: "train", title: "Aeroporto - alloggio", detail: "IPOTESI - Treno e metropolitana, circa 90 minuti porta a porta. Da verificare." },
  { d: 0, s: "12:15", e: "13:15", type: "meal", title: "Pranzo", detail: "Da scegliere." },
  { d: 0, s: "14:30", e: "16:30", type: "visit", p: "stephansdom", title: "Centro storico e Stephansdom" },
  { d: 0, s: "19:00", e: "20:30", type: "meal", title: "Cena in centro", detail: "Da scegliere." },
  { d: 1, s: "09:00", e: "10:30", type: "log", title: "Mercato delle pulci al Naschmarkt", detail: "IPOTESI - Solo il sabato mattina: orario da verificare." },
  { d: 1, s: "11:30", e: "12:30", type: "visit", p: "secession", title: "Secession" },
  { d: 1, s: "13:00", e: "14:00", type: "meal", title: "Pranzo", detail: "Da scegliere." },
  { d: 1, s: "15:30", e: "17:00", type: "visit", p: "westlicht", title: "WestLicht" },
  { d: 1, s: "19:30", e: "21:00", type: "meal", title: "Cena", detail: "Da scegliere." },
  { d: 2, s: "10:30", e: "11:30", type: "visit", p: "riesenrad", title: "Riesenrad" },
  { d: 2, s: "12:30", e: "13:30", type: "meal", title: "Pranzo", detail: "Da scegliere." },
  { d: 2, s: "16:00", e: "17:00", type: "move", mode: "train", title: "Verso l'aeroporto", detail: "IPOTESI - Da definire con l'orario del volo." },
  { d: 2, s: "19:00", e: "20:40", type: "move", mode: "plane", title: "Volo Vienna - Roma", detail: "IPOTESI - Volo della sera, da scegliere." }
];

const COSTS = [
  { d: 0, cat: "Voli", desc: "Volo andata e ritorno", amt: 180, st: "Ipotesi", note: "segnaposto" },
  { d: 0, cat: "Alloggio", desc: "Due notti in zona Neubau", amt: 220, st: "Ipotesi", note: "segnaposto" },
  { d: 0, cat: "Trasporti", desc: "Aeroporto e mezzi urbani", amt: null, st: "Ipotesi", note: "da verificare" },
  { d: 1, cat: "Ingressi", desc: "Musei e Riesenrad", amt: null, st: "Ipotesi", note: "da verificare" },
  { d: 1, cat: "Pasti", desc: "Pasti dei tre giorni", amt: 160, st: "Ipotesi", note: "segnaposto" }
];

const INFO = [
  { t: "Che cos'è questa bozza", items: [
    "Prima stesura senza ricerche: serve a decidere la struttura dei giorni prima di spendere tempo su orari, prezzi e mappa.",
    "Nessun dato è verificato. Il passo successivo aggiunge fonti, posizioni e percorsi."
  ] }
];
const TODO = ["Scegliere quali tappe tenere", "Poi: verifica di orari e prezzi, coordinate, percorsi e mappa"];
const FONTI = [];
