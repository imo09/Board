const TRIP = {
  title: "Vienna in tre giorni",
  sub: "Ven 11 - Dom 13 dicembre 2026 - 1 persona - da Roma FCO - viaggio di esempio",
  verified: "13 novembre 2026",
  center: [48.2082, 16.3738],   /* per alba e tramonto */
  utc: 1,                        /* ore rispetto a UTC nelle date del viaggio */
  hours: [6, 22],                /* finestra del calendario */
  map: true,                     /* false = versione lite senza mappa */
  views: ["giorni", "calendario", "costi", "info"],   /* viste presenti, la prima è quella di apertura */
  speedNote: "Percorsi a piedi calcolati da OSRM (server FOSSGIS) su dati OpenStreetMap, circa 4,5 km/h. Tempi dei mezzi stimati porta a porta.",
  tiles: { cartoKey: "", osm: true }   /* cartografia: vedi istruzioni, capitolo mappa */
};

const DAYS = [
  { date: "2026-12-11", title: "Arrivo e Innere Stadt", sleep: "Vienna" },
  { date: "2026-12-12", title: "Wienzeile, Karlsplatz, Neubau", sleep: "Vienna" },
  { date: "2026-12-13", title: "Prater, Hundertwasser, rientro", sleep: "Roma" }
];

/* Registro dei luoghi: le coordinate si scrivono una volta sola, qui.
   q = qualità della posizione: A due riscontri, B un riscontro, C approssimata (da verificare) */
const PLACES = {
  vie: { n: "Aeroporto di Vienna (VIE)", g: "Flughafen Wien", kind: "hub", ic: "plane", far: true, lat: 48.11028, lng: 16.56972, q: "B",
    src: "Wikipedia EN (punto di riferimento dell'aeroporto, non il terminal)", addr: "Flughafen Wien, 1300 Schwechat" },
  hbf: { n: "Wien Hauptbahnhof", g: "Wien Hauptbahnhof", kind: "hub", lat: 48.186667, lng: 16.38, q: "B",
    src: "Wikipedia EN (centro della stazione; l'atrio con la U1 è sul lato ovest)", addr: "Am Hauptbahnhof 1, 1100 Wien" },
  lodging: { n: "Alloggio (zona Neubau)", kind: "base", lat: 48.1992, lng: 16.3525, q: "C",
    src: "Posizione indicativa presso la U3 Neubaugasse (aggancio OSRM: Mariahilfer Straße, 40 m). Alloggio non ancora scelto",
    addr: "Zona Mariahilfer Straße - Neubaugasse, 1070 Wien",
    note: "Ipotesi di lavoro: alloggio entro 300 m dalla fermata U3 Neubaugasse. Quando l'alloggio è scelto, sostituire coordinate e indirizzo." },
  postsparkasse: { n: "Postsparkasse di Otto Wagner", g: "Österreichische Postsparkasse, Georg-Coch-Platz 2, Wien", wiki: "https://en.wikipedia.org/wiki/Austrian_Postal_Savings_Bank", kind: "poi", lat: 48.21, lng: 16.3803, q: "A",
    src: "structurae.net e Sygic Travel, concordi entro 30 m", addr: "Georg-Coch-Platz 2, 1010 Wien", web: "https://ail.angewandte.at",
    hours: "Da verificare sul sito. Unica indicazione trovata, non ufficiale: lun-ven fino alle 15:00, sab e dom chiuso",
    price: "Non rilevato",
    note: "Capolavoro di Otto Wagner (1904-1906). Si sale dalla scalinata d'ingresso alla grande Kassenhalle con il soffitto in vetro. Messa di venerdì perché nel fine settimana risulta chiusa." },
  stephansdom: { n: "Stephansdom e Haas-Haus", g: "Stephansdom, Stephansplatz, Wien", wiki: "https://en.wikipedia.org/wiki/St._Stephen%27s_Cathedral,_Vienna", kind: "poi", lat: 48.2085, lng: 16.373, q: "A",
    src: "Wikipedia EN + aggancio OSRM a Stephansplatz (38 m)", addr: "Stephansplatz 3, 1010 Wien",
    hours: "Da verificare (visite sospese durante le funzioni)", price: "Navata: da verificare. Torri e catacombe a pagamento: tariffe non rilevate",
    note: "Il duomo gotico e, di fronte, la facciata a specchio dell'Haas-Haus di Hans Hollein (Stock-im-Eisen-Platz 4): il confronto tra i due è il motivo della sosta." },
  looshaus: { n: "Looshaus e Michaelerplatz", g: "Looshaus, Michaelerplatz 3, Wien", wiki: "https://de.wikipedia.org/wiki/Looshaus", kind: "poi", lat: 48.208333, lng: 16.366667, q: "B",
    src: "Wikipedia DE (precisione al secondo d'arco, circa 30 m)", addr: "Michaelerplatz 3, 1010 Wien",
    hours: "Esterno sempre visibile", price: "Gratuito",
    note: "La casa senza ornamento di Adolf Loos (1911) di fronte alla Hofburg. Il tramonto è intorno alle 16:00: si arriva con l'ultima luce." },
  loosbar: { n: "Loos American Bar", g: "Loos American Bar, Kärntner Durchgang 10, Wien", kind: "poi", lat: 48.2068, lng: 16.3716, q: "C",
    src: "Stima non confermata: l'aggancio OSRM cade su Kärntner Straße, il locale è nel passaggio laterale. Errore possibile fino a 50 m",
    addr: "Kärntner Durchgang 10, 1010 Wien", hours: "Da verificare", price: "Consumazione: budget ipotizzato 15,00 €",
    note: "Interno di Adolf Loos del 1908, pochi metri quadrati. Usare il pulsante Google Maps per la posizione esatta." },
  flohmarkt: { n: "Flohmarkt al Naschmarkt", g: "Flohmarkt am Naschmarkt, Wien", kind: "poi", lat: 48.1962, lng: 16.357, q: "C",
    src: "Stima sull'area del mercato presso la U4 Kettenbrückengasse (aggancio OSRM a 5 m da un percorso pedonale senza nome)",
    addr: "Linke Wienzeile, altezza Kettenbrückengasse, 1060 Wien", web: "https://www.wien.gv.at/freizeit/einkaufen/maerkte/flohmarkt/",
    hours: "Ogni sabato 6:30-15:00 (Stadt Wien)", price: "Gratuito",
    note: "Il mercato delle pulci del sabato: antiquariato, orologi, macchine fotografiche. Meglio prima delle 10:00." },
  majolika: { n: "Majolikahaus e Linke Wienzeile 38", g: "Majolikahaus, Linke Wienzeile 40, Wien", wiki: "https://de.wikipedia.org/wiki/Majolikahaus", kind: "poi", lat: 48.1975, lng: 16.359167, q: "B",
    src: "Wikipedia DE", addr: "Linke Wienzeile 38-40, 1060 Wien", hours: "Esterno sempre visibile", price: "Gratuito",
    note: "Le due case d'affitto di Otto Wagner (1898-1899): la facciata in maiolica a fiori e quella con i medaglioni dorati di Koloman Moser." },
  sperl: { n: "Café Sperl", g: "Café Sperl, Gumpendorfer Straße 11, Wien", wiki: "https://de.wikipedia.org/wiki/Caf%C3%A9_Sperl", kind: "poi", lat: 48.199819, lng: 16.361156, q: "B",
    src: "Wikipedia DE", addr: "Gumpendorfer Straße 11, 1060 Wien", hours: "Da verificare", price: "Budget ipotizzato 12,00 €",
    note: "Caffè storico viennese all'angolo con Lehargasse." },
  secession: { n: "Secession", g: "Secession, Friedrichstraße 12, Wien", wiki: "https://de.wikipedia.org/wiki/Wiener_Secessionsgeb%C3%A4ude", kind: "poi", lat: 48.200395, lng: 16.365934, q: "A",
    src: "Wikipedia DE + aggancio OSRM a Friedrichstraße (17 m)", addr: "Friedrichstraße 12, 1010 Wien", web: "https://secession.at/informationen_tickets",
    hours: "Mar-dom 10:00-18:00 (sito ufficiale). Visita guidata in inglese il sabato alle 11:00, 3,00 € oltre al biglietto",
    price: "Tariffa non rilevata sulla pagina ufficiale: 12,00 € è un'ipotesi da verificare",
    note: "L'edificio di Olbrich (1898) con la cupola di foglie dorate e il Fregio di Beethoven di Klimt." },
  karlsplatz: { n: "Padiglione Otto Wagner a Karlsplatz", g: "Otto Wagner Pavillon Karlsplatz, Wien", kind: "poi", lat: 48.2003, lng: 16.3697, q: "C",
    src: "Stima non confermata (aggancio OSRM a 4 m da un percorso pedonale senza nome)", addr: "Karlsplatz, 1040 Wien",
    hours: "Esterno sempre visibile. Apertura interna non verificata", price: "Gratuito (esterno)",
    note: "I due padiglioni della Stadtbahn di Otto Wagner, con la Karlskirche sullo sfondo." },
  mq: { n: "MuseumsQuartier", g: "MuseumsQuartier Wien", wiki: "https://de.wikipedia.org/wiki/MuseumsQuartier", kind: "poi", lat: 48.203333, lng: 16.358889, q: "B",
    src: "Wikipedia DE", addr: "Museumsplatz 1, 1070 Wien", hours: "Cortili liberi. Musei: orari e tariffe non rilevati", price: "Cortili gratuiti",
    note: "Le scuderie imperiali con i cubi di Leopold Museum e mumok. Pranzo in uno dei locali dei cortili, poi il giro degli spazi esterni." },
  westlicht: { n: "WestLicht - museo della fotografia", g: "WestLicht, Westbahnstraße 40, Wien", wiki: "https://de.wikipedia.org/wiki/WestLicht", kind: "poi", lat: 48.20215, lng: 16.342011, q: "B",
    src: "Wikipedia DE", addr: "Westbahnstraße 40, 1070 Wien", web: "https://www.westlicht.com",
    hours: "Mar-ven 14:00-19:00, gio fino alle 21:00, sab-dom 11:00-19:00 (wien.info)", price: "12,00 € (wien.info)",
    note: "Mostre di fotografia e una collezione di circa 700 apparecchi storici. Sulla stessa via ci sono negozi di fotografia e macchine d'epoca: orari del sabato da verificare." },
  wu: { n: "Campus WU - Library and Learning Center", g: "WU Library and Learning Center, Welthandelsplatz 1, Wien", kind: "poi", lat: 48.2137, lng: 16.4088, q: "C",
    src: "Stima non confermata (aggancio OSRM a 26 m da un percorso pedonale senza nome)", addr: "Welthandelsplatz 1, 1020 Wien",
    hours: "Campus all'aperto sempre accessibile. Interni di domenica: da verificare", price: "Gratuito",
    note: "La biblioteca di Zaha Hadid Architects (2013) al centro del campus, con gli edifici di altri studi intorno." },
  riesenrad: { n: "Riesenrad al Prater", g: "Wiener Riesenrad, Riesenradplatz 1, Wien", wiki: "https://de.wikipedia.org/wiki/Wiener_Riesenrad", kind: "poi", lat: 48.2166, lng: 16.3959, q: "C",
    src: "Stima non confermata (area pedonale, aggancio OSRM a 25 m)", addr: "Riesenradplatz 1, 1020 Wien", web: "https://wienerriesenrad.com",
    hours: "A dicembre 10:00-22:15 secondo fonti non ufficiali: da verificare sul sito", price: "14,50 € (wien.info)",
    note: "La ruota del 1897. Il biglietto comprende il piccolo museo nelle cabine storiche." },
  kunsthaus: { n: "Kunst Haus Wien - Museum Hundertwasser", g: "Kunst Haus Wien, Untere Weißgerberstraße 13, Wien", wiki: "https://de.wikipedia.org/wiki/Kunst_Haus_Wien", kind: "poi", lat: 48.211, lng: 16.3932, q: "B",
    src: "Stima confermata dall'aggancio OSRM a Untere Weißgerberstraße (4 m)", addr: "Untere Weißgerberstraße 13, 1030 Wien", web: "https://www.kunsthauswien.com",
    hours: "Tutti i giorni 10:00-18:00 (fonti non ufficiali, coerenti con il Café Friedlich su wien.info)", price: "16,00 € (wien.info)",
    note: "Ex fabbrica di mobili ridisegnata da Hundertwasser: pavimenti ondulati, alberi alle finestre, collezione permanente." },
  hundertwasser: { n: "Hundertwasserhaus", g: "Hundertwasserhaus, Kegelgasse 36, Wien", wiki: "https://en.wikipedia.org/wiki/Hundertwasserhaus", kind: "poi", lat: 48.20722, lng: 16.39417, q: "A",
    src: "Wikipedia EN + aggancio OSRM a Löwengasse (40 m)", addr: "Kegelgasse 34-38, 1030 Wien", hours: "Esterno sempre visibile", price: "Gratuito",
    note: "Casa popolare abitata: si guarda solo da fuori, all'angolo Kegelgasse - Löwengasse." }
};

/* Percorsi a piedi: una richiesta OSRM per catena di tappe. poly = polyline codificata (precisione 5) */
const ROUTES = {
  r1: { stops: ["postsparkasse", "stephansdom", "looshaus", "loosbar"],
    legs: [[713.2, 570.6], [647, 517.8], [536.5, 429.2]],
    poly: "q_geHof~bBvADDt@d@?PpD^TEV`Ap@Oh@XRa@`Cd@z@{AbFvAzBOf@hAhAu@dFHDUt@k@jBUA_BbEuBpGRbBENdBtFd@b@jFbIIb@Hc@PXTS^DZmCNKIWtAqCTHt@_CLHpAeF{AaAN{@ECPyCKC" },
  r2: { stops: ["lodging", "flohmarkt", "majolika", "sperl", "secession", "karlsplatz"],
    legs: [[621.5, 497.3], [267.3, 213.8], [467.5, 377.9], [502.7, 405.9], [418.3, 334.5]],
    poly: "e|deH}yxbBGWNMW}@pG_IFt@d@BDXpBBKa@dC_GGa@b@_AI_BPoALIM?UoBc@N}@}HOFIu@cANi@mFc@iCkCiHsFrFMr@Ls@JGAwFwFyIjD}E}@gBILHMaCoEQaFLcDhBV~@IS{C" },
  r3: { stops: ["karlsplatz", "mq", "westlicht", "lodging"],
    legs: [[1111.5, 888.8], [1411.3, 1129.4], [1084.1, 867.4]],
    poly: "sbeeHue|bBRzC_AHAb@bAjAr@pIp@dBiAdCiDhEkIzSwDxEj@xAgAdAh@p@Bl@}@rABf@l@|B~AzAtBrS\\j\\hATOti@q@Ap@@b@ej@rCUBwGlFw@xD{BmAuE" },
  r4: { stops: ["wu", "riesenrad", "kunsthaus", "hundertwasser"],
    legs: [[1258.2, 1008.5], [958.9, 769.6], [482.5, 386]],
    poly: "wugeHw{ccBzB`FgJxTKz@xApDTfD_@jGqC~IiFzEv@nBsCnDKpAl@\\lDXtAjA\\y@jA`BhAlK`@?z@jJv@C`E|Ar@aDv@Zh@sAzDaDt@u@`U_HVrA" },
  r5: { stops: ["mq", "lodging"],
    legs: [[927.4, 742.2]],
    poly: "aveeHobzbBIJL`@}@rAJnAd@tAb@XJp@`@M^FH^pAhLdAe@DB`@SBIxBeADD`@SBInB_APFhCnMpA~E" }
};

/* Base della mappa schematica: aree, linee e nomi che fanno capire dove ci si trova quando la cartografia non è disponibile.
   areas = poligoni dei quartieri; lines = assi e corsi d'acqua ricalcati con OSRM; labels = nomi di zona in posizione indicativa */
const BASE = {
  desc: "quartieri, assi principali e Donaukanal",
  credit: "quartieri: Stadt Wien, data.gv.at",
  areas: [
    { n: "Josefstadt", at: [48.21105, 16.34784], poly: "w_heHeexbBrAwh@nAgCzb@dGpIgCtBvZQtLqLnbAwAo@mOaAaUsJe@o_@h@eR" },
    { n: "Alsergrund", at: [48.22283, 16.35653], poly: "ohkeHiszbBpR_JdEgEfIeMfEuCxEoAvVwAnEgDpCoEjBlC|Xhw@gBbWqArC}B|{@d@n_@iQyHiA]Mv@oRyF{@oAuCsSeAmEwCoCgg@yHuEqHgDcKv@oAuBwDyDsB{O}Ce@m]|NdBnJkB" },
    { n: "Favoriten", at: [48.15212, 16.38762], poly: "gdbeH{}~bB~LqI`Vw[~jAsiBhzBomCny@af@RhRpe@dA\\cCrBV?wBbf@iA|\\aPaBxJ_Fxk@{BfNuDhOxF`DlF~Ht@|u@fL}EbAh[mMfFqCfMoEu@gJny@oCr\\k@Ge@rA_Gle@oCff@kAph@eChXi@?m@bIo@QEbAsPyDHw@kLmDs]{QU`CyYwMfAcBp@iGcNgHuPoGqWlfBwA`_AVtJm@n@sF`k@aChIyBhDuTrLiSxKwFjF{D`Go_@aWkNuHrC_c@pAoKoDuAyDEc@iKqFpB}EtDf@vBy@ZHxDuCPHlCuAf@N`GaFdBaCgM}IqWeBsN_Bwa@sEuYiWcgAEsCeAcFeBHcAo@uLum@|E_B|JgL" },
    { n: "Simmering", at: [48.16399, 16.44627], poly: "}gbeHo`gcBrByS}CqFPoE}A_Afw@e`E|Kih@`g@cbBfLqg@hIsYkFoJzl@ogB~O~~AqAzAkCzIkHlP|C|GxPdWqGnq@tAWiC|L}B~@dGgBdEbAfEjCzc@pu@xArAxFvJv@{B~Sz\\TrDlGtLHpAvG~KzCnJz@~El@vMjCn{Aoy@`f@izBnmCuj@r}@k@IsD~G_@EYdBPeJqReCoGqNaKuKl@yAeCsC}@zAsDgFkGfGsDeJxDuE}@qB|Jch@gMyL~ByJaFgDdAiKsIkC|CuHrC_S" },
    { n: "Meidling", at: [48.1705, 16.32232], poly: "}xbeH{vvbBxx@_q@nBzN|HvS`CfM`FeBOaGtAg@ImCtCQIyDx@[g@wBfH_FfDgAb@hKxDDnDtAqAnKsC~b@jNtHn_@`W|IcLtM}H~IbNfLnOeFzTsCpYGhEvAfAt@pLIf@mF~@hAxM_CUuCz`@cEt^mBbKlXjh@{F`\\}NsHoIiI}A`Y_h@eWmImCb@yLqDeB}GmKdD_ElGed@i[ic@sl@i_@oJ{@kIcDlKwj@TwMWwMu@oFkCuHqEuGyGoFaDgF_AiFMyL" },
    { n: "Margareten", at: [48.18678, 16.3559], poly: "{kdeHqezbB`JcH`C{Et@z@`JmMrKlJlLcO~XmXxOxo@lEjVnAxL`Bj`@yx@~p@s@wUsEud@wAcEeCaDyGmEgDm@{HViDoBmDiJ_BoN|@s@" },
    { n: "Mariahilf", at: [48.19476, 16.34982], poly: "mleeHc|zbBjFcK~CiE`@LnMnY`CpMk@b@bB`OnBdGhExDbJMtEhAfIfHdCpH`Ezb@rAbf@gCnDuJlDiTwJyCg@_Dl@oDw^mEwYwJm^wHgd@wAeDmEmFdDoH" },
    { n: "Innere Stadt", at: [48.20836, 16.36941], poly: "{hheH_x|bBxCiDtMoIlEaIhCgQTyK_@_Mx@cB\\@DsAjNvBt[`T~WvYfCjQmEjYGpDj@vD|DtI_AGeDrEkJ~Rw[zd@kH`B{b@eGhBoW}Xiw@kBmCvJqN" },
    { n: "Leopoldstadt", at: [48.20362, 16.42331], poly: "ohkeHqxbcBf|@aoAnj@c{@`hBovCtrBqmDft@csAzXoj@`LfSiIrYgLpg@mJt\\uJtXuRrr@acAjgF{Lhj@kF|Msb@|y@oFxGwRlMoD~EeCnIyDd]qCtH}G`G}V`E}P|IoCpDoBbGcBrPRnGfAfGvCbIvB|@ErAy@P]jA^nOi@tMaApHgBxFsDlFuNlJcQfW}DtD}HzAqNZoEhAmCeQeAImI{IyIo`@jIuVhMkJ{AyH}ImScAi@oFt@gE~Ekd@}eAtZe`@" },
    { n: "Wieden", at: [48.19257, 16.37037], poly: "o`eeHsv|bBx@mH_A_GrAo@|IbApRaKhIuGh[}OfA\\fLfl@bAn@dBIdAbFDrCxDvP_YlXmLbOsKmJaJlMu@{@aCzEsJrHgC}MiMcY\\E{EsLIsFvCaR" },
    { n: "Ottakring", at: [48.2154, 16.2996], poly: "_jjeHi}ibBr@q@XkItAgEn@mF~DqInAw@fBoDdAqFaBiNdDMrJxDSmK}J}ToEw\\CeFzAyEGiB|CeMi@sHqBI{AnAMuHb@eJPqAxJwBa@gH}B]`B_Fm@c@x@}B^aJwC{B`Q_r@jRlEXaG`FjAL_JfDv@GaRhL{@yE}d@eDaj@zP^LgDbBn@pK^lVdKrIUZpT{RfaC~IbAbFk@k@fEnItD_AhGVxAcCQgEtXI~FXJqCr[eKz]vDl]Q`KmAxOkCkGaNz@{McA{AlBeFPg@jJoCtLQ|Ov@bBKt@c@QUxBFfJuAhLoDdIwAv@}BtECbGuAbLL`Gt@zD_A|EeDrDgDfN@jGy@hJkBhD[lCcEdKyEeHScBwBiEuCuAoDsFGaIf@aADuCmCuKKcCi@[oAiI_B}EIqSo@gIi@s\\" },
    { n: "Hernals", at: [48.23372, 16.29025], poly: "kcpeHiukbBjACnCeDbCp@rF{@Ak@~BqAQw@xA{@nIw@LiDtAfAvBtIfA~@^YnDnLxD~H|Go@`Ar@x@{No@kP\\wV_@eJ~EiCnAtJi@hE`EtCr@bEdDKx@~LjBdKxApErBhAnBoG|B}Tu@_RJoNnQHgBsKaCiCNaMjBqF~CiDKwD|G_A~Iub@pBsDjBaTkA_S|DCViEfHlADyEjCq[bDx@l@aHbHhCj@{R{A{Fy@I}AmCvBaFhCRdFiOd@qDdM{[n@d@`@u@fGnEhAiDlA`AjCcThK`DvAwRz^bPMfD{P_@dD`j@xE|d@iLz@F`RgDw@M~IaFkAY`GkRmEaQ~q@vCzB_@`Jy@|Bl@b@aB~E|B\\`@fHyJvBs@pJ@tHHdAdBqAfBJh@rH}CdMFhB{AxEJ`HnEn[tJhTRlKsJyDeDL`BhNeApFgBnDoAv@_EpIo@lFuAfEYjIs@p@h@r\\n@fIHpS~A|EnAhIh@ZJbClCtKEtCg@`AF`InDrFtCtAvBhERbBbDjF~EtG`@KLjAZOSpAh@bErEnFo@|@oWsW_MeHkIyBkGI{GkEsLw]iCqE_FqEcMoWeIiIUPhClDg@|DTbAe@~@NnA}@F_@hAZ|@MlAk@`@mD|LsDhSNjCg@rKeGZV_AuAi@cHh@iEqGcLkBv@}COaBjAkEeCeB`@}A_AkBuC}Ap@yAIgAgABcBmFsBgAgEzBoOub@sDc@wEvEM|KyAtIStHkAZUsD\\oV_BgJeD{IeDkShAmWcEePu@oMuAsEpF`BrAS" },
    { n: "Brigittenau", at: [48.24021, 16.3773], poly: "}_qeHa~|bB~d@c_@za@{_@zn@_p@~a@if@jd@|eAfE_FnFu@bAh@|IlS~AtGMp@_M|IkItVxIn`@lIzIdAHlCdQqEzCeLlPeHzEoUfIaIS}IgBsRoIqVgPy[qYyGsDyFyAoDCiFnAiYzMcIKcOnDsG_Y`HsF" },
    { n: "Rudolfsheim-Fünfhaus", at: [48.19547, 16.32606], poly: "e}eeHuptbBzAcR[qTzNq@hh@iLxCf@hTvJtJmDfCoDlDjIhIhHrFtIbC`Kd@zLOzOkApIwNdv@_BlO{AyAs@i@iBnA_JaEb@s]sCg@qFpUaBnBeEmBeEzXaLeFyNuAGuYqUbl@a@lCoIuDj@gEcFj@_JcA~OcnB" },
    { n: "Währing", at: [48.23556, 16.31898], poly: "awneH{rmbB|AeJfB}c@`CoNnEwNxGt@p@qJhBb@tHaOzHq]o@sBhEgYlBnGRZXs@rBiRpMsi@Jmo@fSAAyZp@iIc@uAt@o@rAqPo@_@f@}HeC_@TwH~IrA@cJm@aF`@wA`FvNpCrClh@tIjCxEBjC`D~Qn@bA~ZdIwAvRiKaDkCbTmAaAiAhDgGoEa@t@o@e@eMz[e@pDeFhOiCSwB`F|AlCx@HzAzFk@zRcHiCm@`HcDy@kCp[ExEgHmAWhE}DBjA~RkB`TqBrD_Jtb@}G~@JvD_DhDkBpFO`M`ChCfBrKoQIKnNt@~Q}B|ToBnGsBiAyAqEkBeKy@_MeDJs@cEaEuCh@iEoAuJ_FhC^dJ]vVn@jPy@zNaAs@}Gn@yD_IoDoL_@XgA_AwBuIuAgAzAcGVqH|CsV" },
    { n: "Donaustadt", at: [48.21889, 16.49492], poly: "alseH_ewcBbAcHpKuYLmB|R|FhDof@~MiIlC}M~DyYbDa_@_DqAkDqP_BePvFks@bt@zYbi@rH~OpFvLdBZ{u@bNdA~Fs]nf@pPby@~Q|LxAdN[rNvBv[`N`\\rT~L|KlWzGjAdArS{NbNiErLkHzEwAfO~KpLpEpSbCpC_SpBcC~FfCwItTb^tGzABnMwPdEsIgDvZdF}@~BiMCwEiC{FdCmTqL|DqAlL}BlCeBQiA_CFiQkAgCoAWg@gA`@_CScHvC}H|@aAhB\\fHiApI_EfG|@`A|DLfL{@xDrCa@tDqBdQ}DzA}FpByBtGxAd@YpCoGlIeJHyLz@mEgKhMaBk@{@_H@wCdA_H|FmH`EyBhHgIeAgD_GqFaI}ZZiIw@gCD{BhBiKpGcLzHaEfGo@~NlIlFtGZ}BbBBlA_ElDyEdKiHhxAdEhJvAeZjeBePxpAoErUyFtOox@jsAsD|HkVxt@_BjP{l@ngBuDwG{Xnj@gt@bsAk{A|jCox@tsAkqBp`Dmt@deAob@`j@oPy_@_G~DuCmA]cR{@yI_BmHyCiHkCaEwIeIgB_\\c@a@b@_Ns@_Qb@}EsB}Sy`@oA~BaMeM_Fya@yWOwHcAsGgLhHkAiU|@{e@cAaAxPkRwV}Ows@uvAmJiVmJeOm@gHhGiTnBoRcC\\aFo@{SqJcF_AwKfD}Dw@eDHKx@qCg@]nBwNzCuUjB_O{AgA`@dAaOhCgnAvB|@xKsq@rG}T~Fca@dDbAbDsKpY~KrBzFpYjSxPbI\\gF" },
    { n: "Neubau", at: [48.20254, 16.34698], poly: "kvfeHadvbBhLw`APuLuBwZpYkb@fFtGbBbGpG``@xLle@rH~q@ac@jKqWhAqHcBiGmDS{A" },
    { n: "Landstraße", at: [48.19376, 16.39611], poly: "eofeH{macB~O_CbDuBvC}DnBeGtDq\\nBqHjEoGrTeObLmQx`@wy@~DiN`Jkd@|A~@U~DnCdERlBsF`d@sDzJrIjCeAhK`FfD_CxJfMxL}Jbh@|@pByDtErDdJjGgGrDfF|@{AdCrCUh@Wn@`KtKnGpNpRdC]bIqP~Xs[bc@_DvCgF~BkLxMgFfBLl@gA]oThKiPlLeSdKcIkAsAn@gA_HqWkYe]aUoPmC_D}HqAaHQmIbAiKtBeIhFoGrK{FjIsB" }
  ],
  lines: [
    { n: "Ring", kind: "road", dist: 5511.9, poly: "cjgeHoy}bB`@KHy@^LJgAf@Zv@mCdC|@lESdAeCp@MpBfB~@sCx@l@TcAxAvAt\\j]TlAdCwAs@XFjC{@`@Dx@cDrUJHs@`C}Ej\\gAdBJPuExGm@|AGUeIfLaI}AE`@_J{A?v@oRwD}@{BFw@Uc@G[h@k@gTkm@dBmBe@qAMNLOd@pA`TmU~B}AvB{EZT`AaI[QNsA" },
    { n: "Donaukanal", kind: "water", dist: 5524.9, poly: "ykjeHkc{bBpNcOrMuA|GMxIcCbOqT]`@d@pA`UkV]_BbGmNzA}Mz@BFoCJaNiAU]eCJ}At@QtAaa@pNeScAeN`A[dNsBMgI`@aAzD}@pDyC~BmExAaMjEbBlDoW~B{EfEsD" },
    { kind: "road", dist: 2778, legs: [752.4, 618.9, 1406.7], names: ["Kärntner Straße", "Rotenturmstraße", "Praterstraße"], poly: "mreeHs`|bBPmCsD_BWk@cMuEiK}AqA{@T_AYlAgC}BMs@yH{Ka@yAsEyDl@}Cj@eFmFsCNoEaFeOkD{EmSye@Jw@g@mH" },
    { n: "Hauptallee", kind: "road", dist: 2362.2, poly: "klheHaw`cBlB{Cd@E~Ou`@cBsBpBuE_Au@dDlC~EeLf@Ofa@k`A}AgBz@gIb@I" },
    { n: "Mariahilfer Straße", kind: "road", dist: 2044.7, poly: "amdeHaivbBgBb@a@wB[HGeAq@G?UPUOyCgAaMrHyCcCyQq@qD}BqJ}DcNqA_FyBsKgDsUiAkDcBcCPw@FHRg@LA" }
  ],
  labels: [
    { n: "Naschmarkt", at: [48.1987, 16.3628] }, { n: "Hofburg", at: [48.2065, 16.3655] },
    { n: "Stadtpark", at: [48.205, 16.3795] }, { n: "Prater", at: [48.2125, 16.405] }
  ]
};

/* Alternative: programmi diversi per lo stesso giorno. Una variante sostituisce gli eventi base che iniziano tra from e to
   (senza from e to: tutto il giorno) con gli eventi che portano il suo id nel campo v. set = nome dello scenario, facoltativo */
const VARIANTS = [
  { id: "sab-leopold", d: 1, short: "Leopold Museum", name: "Pomeriggio al Leopold Museum", from: "15:00", to: "17:05",
    why: "Per pioggia o stanchezza: si resta nel MuseumsQuartier invece di attraversare Neubau fino a WestLicht.",
    pro: "circa 1,6 km a piedi in meno, tutto al coperto, Schiele e Klimt", contro: "7,00 € in più, si rinuncia alla fotografia e ai negozi di Westbahnstraße" },
  { id: "dom-lento", d: 2, short: "Senza campus WU", name: "Mattina senza campus WU", from: "09:15", to: "12:10",
    why: "Per una partenza più tranquilla o con il maltempo: si salta il campus e si va direttamente al Prater.",
    pro: "circa 1,3 km a piedi in meno, un'ora di margine al Prater", contro: "si perde la biblioteca di Zaha Hadid" }
];

/* Eventi: tutto ciò che compare in calendario e nell'agenda del giorno.
   type: visit | meal | move | log. Per i move: mode, from, to e, se a piedi, r = [percorso, indice tratta] */
const EVENTS = [
  /* ---- Venerdì 11 ---- */
  { d: 0, s: "06:30", e: "08:30", type: "log", title: "In aeroporto a Roma FCO",
    detail: "IPOTESI - Arrivo a Fiumicino due ore prima del volo. Solo bagaglio a mano. Check-in online: apertura da verificare con la compagnia scelta." },
  { d: 0, s: "08:30", e: "10:10", type: "move", mode: "plane", to: "vie", title: "Volo Roma FCO - Vienna VIE",
    detail: "IPOTESI - Volo diretto del mattino, circa 1 h 40 min. Compagnia, orario e prezzo non sono stati cercati: da scegliere. Gli orari del giorno dipendono da questo arrivo." },
  { d: 0, s: "10:10", e: "10:45", type: "log", p: "vie", title: "Uscita e biglietto del treno",
    detail: "Con il solo bagaglio a mano si esce senza attese al nastro. Biglietto del treno alle macchinette ÖBB o in app. Margine di 35 minuti tra atterraggio e partenza del treno." },
  { d: 0, s: "10:45", e: "11:05", type: "move", mode: "train", from: "vie", to: "hbf", title: "Railjet per Wien Hbf",
    detail: "STIMA - Treni ÖBB a lunga percorrenza tra aeroporto e Wien Hauptbahnhof: da 14 minuti (ÖBB). Tariffa 5,50 € secondo fonti non ufficiali.\nATTENZIONE - Lavori 2026 sulla linea S-Bahn: secondo fonti non ufficiali la S7 è limitata a St. Marx dal 7 settembre e il CAT è sostituito da autobus dal 24 agosto. Per questo l'itinerario usa il Railjet su Hbf. Verificare su oebb.at la situazione di dicembre e l'orario reale." },
  { d: 0, s: "11:05", e: "11:40", type: "move", mode: "metro", from: "hbf", to: "lodging", title: "U1 + U3 per Neubaugasse",
    detail: "STIMA porta a porta 30-35 minuti: U1 da Hauptbahnhof a Stephansplatz, cambio, U3 fino a Neubaugasse, poi a piedi. Corsa singola 3,00 € in app WienMobil." },
  { d: 0, s: "11:40", e: "12:00", type: "log", p: "lodging", title: "Deposito bagaglio",
    detail: "IPOTESI - Il check-in di norma apre nel pomeriggio: lasciare il bagaglio e ripartire leggeri. Da confermare con l'alloggio scelto." },
  { d: 0, s: "12:05", e: "13:05", type: "meal", title: "Pranzo in zona Neubau",
    detail: "Locale da scegliere tra Neubaugasse e Spittelberg. Budget ipotizzato 18,00 €." },
  { d: 0, s: "13:10", e: "13:35", type: "move", mode: "metro", from: "lodging", to: "postsparkasse", title: "U3 per Stubentor",
    detail: "STIMA porta a porta 20-25 minuti: U3 da Neubaugasse a Stubentor (4 fermate), poi circa 5 minuti a piedi lungo lo Stubenring fino a Georg-Coch-Platz." },
  { d: 0, s: "13:40", e: "14:30", type: "visit", p: "postsparkasse", title: "Postsparkasse di Otto Wagner" },
  { d: 0, s: "14:30", e: "14:42", type: "move", mode: "walk", from: "postsparkasse", to: "stephansdom", r: ["r1", 0], title: "A piedi verso Stephansplatz" },
  { d: 0, s: "14:45", e: "15:45", type: "visit", p: "stephansdom", title: "Stephansdom e Haas-Haus" },
  { d: 0, s: "15:45", e: "15:55", type: "move", mode: "walk", from: "stephansdom", to: "looshaus", r: ["r1", 1], title: "A piedi per Graben e Kohlmarkt" },
  { d: 0, s: "15:55", e: "16:25", type: "visit", p: "looshaus", title: "Looshaus e Michaelerplatz" },
  { d: 0, s: "16:25", e: "16:34", type: "move", mode: "walk", from: "looshaus", to: "loosbar", r: ["r1", 2], title: "A piedi verso Kärntner Straße" },
  { d: 0, s: "16:35", e: "17:20", type: "meal", p: "loosbar", title: "Aperitivo al Loos American Bar" },
  { d: 0, s: "17:20", e: "18:50", type: "log", title: "Tempo libero in centro",
    detail: "Margine senza programma: Graben, Kohlmarkt, cortili della Hofburg illuminati. Assorbe eventuali ritardi del volo." },
  { d: 0, s: "19:00", e: "20:30", type: "meal", title: "Cena in centro",
    detail: "Trattoria viennese da scegliere e prenotare: il venerdì sera i locali storici si riempiono. Budget ipotizzato 30,00 €." },
  { d: 0, s: "20:35", e: "21:00", type: "move", mode: "metro", from: "stephansdom", to: "lodging", title: "U3 da Stephansplatz",
    detail: "STIMA porta a porta 20-25 minuti: U3 da Stephansplatz a Neubaugasse (3 fermate). Venerdì e sabato la metropolitana viaggia tutta la notte." },
  { d: 0, s: "21:00", e: "21:15", type: "log", p: "lodging", title: "Check-in",
    detail: "IPOTESI - Avvisare l'alloggio dell'arrivo serale se la reception non è aperta 24 ore." },

  /* ---- Sabato 12 ---- */
  { d: 1, s: "08:10", e: "08:40", type: "meal", title: "Colazione vicino all'alloggio", detail: "Budget ipotizzato 8,00 €." },
  { d: 1, s: "08:45", e: "08:54", type: "move", mode: "walk", from: "lodging", to: "flohmarkt", r: ["r2", 0], title: "A piedi verso la Wienzeile" },
  { d: 1, s: "08:55", e: "10:10", type: "visit", p: "flohmarkt", title: "Flohmarkt al Naschmarkt" },
  { d: 1, s: "10:10", e: "10:14", type: "move", mode: "walk", from: "flohmarkt", to: "majolika", r: ["r2", 1], title: "A piedi lungo la Linke Wienzeile" },
  { d: 1, s: "10:15", e: "10:35", type: "visit", p: "majolika", title: "Majolikahaus di Otto Wagner" },
  { d: 1, s: "10:35", e: "10:42", type: "move", mode: "walk", from: "majolika", to: "sperl", r: ["r2", 2], title: "A piedi verso Gumpendorfer Straße" },
  { d: 1, s: "10:45", e: "11:30", type: "meal", p: "sperl", title: "Caffè al Café Sperl" },
  { d: 1, s: "11:30", e: "11:37", type: "move", mode: "walk", from: "sperl", to: "secession", r: ["r2", 3], title: "A piedi verso la Secession" },
  { d: 1, s: "11:40", e: "12:40", type: "visit", p: "secession", title: "Secession e Fregio di Beethoven" },
  { d: 1, s: "12:40", e: "12:46", type: "move", mode: "walk", from: "secession", to: "karlsplatz", r: ["r2", 4], title: "A piedi verso Karlsplatz" },
  { d: 1, s: "12:50", e: "13:10", type: "visit", p: "karlsplatz", title: "Padiglioni di Otto Wagner" },
  { d: 1, s: "13:10", e: "13:25", type: "move", mode: "walk", from: "karlsplatz", to: "mq", r: ["r3", 0], title: "A piedi verso il MuseumsQuartier" },
  { d: 1, s: "13:30", e: "14:30", type: "meal", p: "mq", title: "Pranzo al MuseumsQuartier",
    detail: "Locale da scegliere nei cortili. Budget ipotizzato 18,00 €." },
  { d: 1, s: "14:30", e: "15:00", type: "visit", p: "mq", title: "Cortili del MuseumsQuartier" },
  { d: 1, s: "15:00", e: "15:19", type: "move", mode: "walk", from: "mq", to: "westlicht", r: ["r3", 1], title: "A piedi attraverso Neubau" },
  { d: 1, s: "15:20", e: "16:50", type: "visit", p: "westlicht", title: "WestLicht e negozi di fotografia" },
  { d: 1, s: "16:50", e: "17:05", type: "move", mode: "walk", from: "westlicht", to: "lodging", r: ["r3", 2], title: "A piedi verso l'alloggio" },
  { d: 1, s: "17:05", e: "19:15", type: "log", p: "lodging", title: "Pausa in alloggio",
    detail: "Giornata tutta a piedi, circa 5,9 km: due ore di riposo prima di cena. Il tramonto è intorno alle 16:00." },
  { d: 1, s: "19:30", e: "21:00", type: "meal", title: "Cena a Neubau o Spittelberg",
    detail: "Locale da scegliere e prenotare per il sabato sera. Budget ipotizzato 30,00 €." },

  /* ---- Domenica 13 ---- */
  { d: 2, s: "07:50", e: "08:20", type: "meal", title: "Colazione", detail: "Budget ipotizzato 8,00 €." },
  { d: 2, s: "08:20", e: "08:30", type: "log", p: "lodging", title: "Check-out",
    detail: "IPOTESI - Si parte con il bagaglio: non si torna in zona Neubau." },
  { d: 2, s: "08:30", e: "09:00", type: "move", mode: "metro", from: "lodging", to: "hbf", title: "U3 + U1 per Wien Hbf",
    detail: "STIMA porta a porta 30 minuti: U3 da Neubaugasse a Stephansplatz, cambio, U1 fino a Hauptbahnhof." },
  { d: 2, s: "09:00", e: "09:15", type: "log", p: "hbf", title: "Deposito bagagli a Wien Hbf",
    detail: "Il treno per l'aeroporto parte da qui: il bagaglio resta in stazione fino al pomeriggio. Disponibilità degli armadietti e prezzo non verificati." },
  { d: 2, s: "09:15", e: "09:50", type: "move", mode: "metro", from: "hbf", to: "wu", title: "U1 + U2 per Krieau",
    detail: "STIMA porta a porta 35 minuti: U1 da Hauptbahnhof a Praterstern, cambio, U2 fino a Krieau, poi pochi minuti a piedi nel campus. Percorso da verificare in WienMobil." },
  { d: 2, s: "09:50", e: "10:50", type: "visit", p: "wu", title: "Campus WU e biblioteca di Zaha Hadid" },
  { d: 2, s: "10:50", e: "11:07", type: "move", mode: "walk", from: "wu", to: "riesenrad", r: ["r4", 0], title: "A piedi attraverso il Prater" },
  { d: 2, s: "11:10", e: "12:10", type: "visit", p: "riesenrad", title: "Riesenrad" },
  { d: 2, s: "12:10", e: "12:23", type: "move", mode: "walk", from: "riesenrad", to: "kunsthaus", r: ["r4", 1], title: "A piedi oltre il Donaukanal" },
  { d: 2, s: "12:30", e: "13:30", type: "meal", p: "kunsthaus", title: "Pranzo al Café Friedlich",
    detail: "Il caffè interno al Kunst Haus Wien, aperto tutti i giorni 10:00-18:00 (wien.info). Budget ipotizzato 18,00 €." },
  { d: 2, s: "13:30", e: "14:45", type: "visit", p: "kunsthaus", title: "Museum Hundertwasser" },
  { d: 2, s: "14:45", e: "14:52", type: "move", mode: "walk", from: "kunsthaus", to: "hundertwasser", r: ["r4", 2], title: "A piedi verso Kegelgasse" },
  { d: 2, s: "14:55", e: "15:20", type: "visit", p: "hundertwasser", title: "Hundertwasserhaus" },
  { d: 2, s: "15:20", e: "15:50", type: "move", mode: "tram", from: "hundertwasser", to: "hbf", title: "Tram per Wien Hbf",
    detail: "STIMA porta a porta 30 minuti. Linea e fermata NON verificate: l'ipotesi è il tram O da Radetzkyplatz verso Hauptbahnhof. Controllare in WienMobil prima di partire." },
  { d: 2, s: "15:50", e: "16:05", type: "log", p: "hbf", title: "Ritiro bagaglio",
    detail: "Quindici minuti per armadietto e binario." },
  { d: 2, s: "16:10", e: "16:30", type: "move", mode: "train", from: "hbf", to: "vie", title: "Railjet per l'aeroporto",
    detail: "STIMA - Da Wien Hauptbahnhof all'aeroporto da 14 minuti (ÖBB). Tariffa 5,50 € secondo fonti non ufficiali. Orario reale da scegliere su oebb.at." },
  { d: 2, s: "16:30", e: "19:00", type: "log", p: "vie", title: "In aeroporto",
    detail: "IPOTESI - Arrivo due ore e mezza prima del volo: il margine copre un treno perso (frequenza da verificare)." },
  { d: 2, s: "19:00", e: "20:40", type: "move", mode: "plane", from: "vie", title: "Volo Vienna VIE - Roma FCO",
    detail: "IPOTESI - Volo diretto della sera, circa 1 h 40 min. Da scegliere insieme all'andata." },
  /* ---- Variante sab-leopold (sabato 15:00 - 17:05) ---- */
  { d: 1, v: "sab-leopold", s: "15:00", e: "16:45", type: "visit", p: "mq", title: "Leopold Museum",
    detail: "Nel MuseumsQuartier. Aperto tutti i giorni tranne il martedì 10:00-18:00; dal 7 dicembre al 10 gennaio aperto ogni giorno (sito ufficiale). Intero 19,00 €. La cassa chiude mezz'ora prima della chiusura. Collezione Wien 1900 con Schiele e Klimt." },
  { d: 1, v: "sab-leopold", s: "16:45", e: "16:58", type: "move", mode: "walk", from: "mq", to: "lodging", r: ["r5", 0], title: "A piedi verso l'alloggio" },

  /* ---- Variante dom-lento (domenica 09:15 - 12:10) ---- */
  { d: 2, v: "dom-lento", s: "09:15", e: "09:45", type: "move", mode: "metro", from: "hbf", to: "riesenrad", title: "U1 per Praterstern",
    detail: "STIMA porta a porta 30 minuti: U1 diretta da Hauptbahnhof a Praterstern, poi circa 5 minuti a piedi fino a Riesenradplatz. Da verificare in WienMobil." },
  { d: 2, v: "dom-lento", s: "09:45", e: "10:00", type: "log", p: "riesenrad", title: "Attesa dell'apertura",
    detail: "Il Riesenrad a dicembre apre alle 10:00 secondo fonti non ufficiali: se l'orario è confermato, si arriva per il primo giro." },
  { d: 2, v: "dom-lento", s: "10:00", e: "11:00", type: "visit", p: "riesenrad", title: "Riesenrad" },
  { d: 2, v: "dom-lento", s: "11:00", e: "12:10", type: "log", p: "riesenrad", title: "Passeggiata nel Prater",
    detail: "Tempo libero tra il Wurstelprater e l'inizio della Hauptallee, con margine per un caffè." }
];

/* Spese: st = Confermato | Prenotato | Stima (prezzo da fonte) | Ipotesi (segnaposto). amt null = importo da definire.
   v = voce contata solo con quella variante attiva; x = voce base esclusa quando una di quelle varianti è attiva */
const COSTS = [
  { d: 0, cat: "Voli", desc: "Volo Roma FCO - Vienna VIE", amt: 90, st: "Ipotesi", note: "segnaposto, nessuna quotazione cercata" },
  { d: 2, cat: "Voli", desc: "Volo Vienna VIE - Roma FCO", amt: 90, st: "Ipotesi", note: "segnaposto, nessuna quotazione cercata" },
  { d: 0, cat: "Alloggio", desc: "Alloggio zona Neubau", amt: 110, st: "Ipotesi", note: "notte 1/2, segnaposto" },
  { d: 1, cat: "Alloggio", desc: "Alloggio zona Neubau", amt: 110, st: "Ipotesi", note: "notte 2/2, segnaposto" },
  { d: 0, cat: "Trasporti", desc: "Railjet aeroporto - Wien Hbf", amt: 5.5, st: "Stima", note: "tariffa da fonti non ufficiali" },
  { d: 0, cat: "Trasporti", desc: "Wiener Linien, 3 corse singole", amt: 9, st: "Stima", note: "3,00 € a corsa in app (tariffa ufficiale 2026)" },
  { d: 2, cat: "Trasporti", desc: "Wiener Linien, 3 corse singole", amt: 9, st: "Stima", note: "3,00 € a corsa in app (tariffa ufficiale 2026)" },
  { d: 2, cat: "Trasporti", desc: "Railjet Wien Hbf - aeroporto", amt: 5.5, st: "Stima", note: "tariffa da fonti non ufficiali" },
  { d: 2, cat: "Trasporti", desc: "Deposito bagagli Wien Hbf", amt: null, st: "Ipotesi", note: "prezzo non verificato" },
  { d: 0, cat: "Ingressi", desc: "Stephansdom, eventuali aree a pagamento", amt: null, st: "Ipotesi", note: "tariffe non rilevate" },
  { d: 1, cat: "Ingressi", desc: "Secession", amt: 12, st: "Ipotesi", note: "tariffa non rilevata, da verificare" },
  { d: 1, cat: "Ingressi", desc: "WestLicht", amt: 12, st: "Stima", note: "prezzo intero da wien.info", x: ["sab-leopold"] },
  { d: 1, cat: "Ingressi", desc: "Leopold Museum", amt: 19, st: "Stima", note: "prezzo intero dal sito ufficiale", v: "sab-leopold" },
  { d: 2, cat: "Ingressi", desc: "Riesenrad", amt: 14.5, st: "Stima", note: "prezzo intero da wien.info" },
  { d: 2, cat: "Ingressi", desc: "Kunst Haus Wien", amt: 16, st: "Stima", note: "prezzo intero da wien.info" },
  { d: 0, cat: "Pasti", desc: "Pranzo", amt: 18, st: "Ipotesi", note: "budget segnaposto" },
  { d: 0, cat: "Pasti", desc: "Aperitivo al Loos American Bar", amt: 15, st: "Ipotesi", note: "budget segnaposto" },
  { d: 0, cat: "Pasti", desc: "Cena", amt: 30, st: "Ipotesi", note: "budget segnaposto" },
  { d: 1, cat: "Pasti", desc: "Colazione", amt: 8, st: "Ipotesi", note: "budget segnaposto" },
  { d: 1, cat: "Pasti", desc: "Café Sperl", amt: 12, st: "Ipotesi", note: "budget segnaposto" },
  { d: 1, cat: "Pasti", desc: "Pranzo", amt: 18, st: "Ipotesi", note: "budget segnaposto" },
  { d: 1, cat: "Pasti", desc: "Cena", amt: 30, st: "Ipotesi", note: "budget segnaposto" },
  { d: 2, cat: "Pasti", desc: "Colazione", amt: 8, st: "Ipotesi", note: "budget segnaposto" },
  { d: 2, cat: "Pasti", desc: "Pranzo al Café Friedlich", amt: 18, st: "Ipotesi", note: "budget segnaposto" }
];

/* Schede della sezione Info. Ogni voce è una riga di testo; i link vanno in FONTI */
const INFO = [
  { t: "Come leggere questo esempio", items: [
    "Viaggio inventato per provare le istruzioni: date, voli, alloggio e budget dei pasti sono ipotesi, marcate come tali.",
    "Orari, tariffe e percorsi con la dicitura di una fonte sono stati verificati il 13 novembre 2026.",
    "Tutto ciò che non è stato trovato è scritto come da verificare, non stimato a memoria.",
    "Sabato e domenica hanno un'alternativa pronta: si attiva dal selettore Programma e cambia mappa, calendario e costi."
  ] },
  { t: "Aeroporto e città", items: [
    "Railjet e altri treni ÖBB a lunga percorrenza tra aeroporto e Wien Hauptbahnhof: da 14 minuti (ÖBB).",
    "Tariffa 5,50 € a tratta secondo fonti non ufficiali: da verificare su oebb.at.",
    "Lavori 2026 sulla S-Bahn, da fonti non ufficiali: S7 limitata a St. Marx dal 7 settembre, CAT sostituito da autobus per Wien Mitte dal 24 agosto. Verificare la situazione di dicembre.",
    "Da Wien Hbf si prosegue in U1."
  ] },
  { t: "Muoversi a Vienna", items: [
    "Corsa singola Wiener Linien: 3,00 € in app, 3,20 € cartaceo (tariffe dal 1 gennaio 2026).",
    "24 ore: 9,70 € in app. 7 giorni: 25,20 € in app.",
    "I biglietti da 48 e 72 ore non esistono più dal 1 gennaio 2026.",
    "In questo itinerario servono 6 corse in tre giorni: 6 singole costano 18,00 €, due biglietti da 24 ore 19,40 €. Il sabato è tutto a piedi.",
    "Venerdì e sabato la metropolitana viaggia tutta la notte."
  ] },
  { t: "Mappa e percorsi", items: [
    "I percorsi a piedi seguono le strade reali: sono calcolati da OSRM sul server FOSSGIS con dati OpenStreetMap, a circa 4,5 km/h.",
    "I tempi dei mezzi sono stime porta a porta, comprese attese e tratti a piedi: sulla mappa sono le linee tratteggiate.",
    "Ogni luogo ha una classe di posizione. A: due riscontri concordi. B: un riscontro. C: approssimata, bordo tratteggiato, da verificare.",
    "Per la posizione esatta e la navigazione usare i pulsanti nella scheda di ogni luogo: Google Maps e Apple Maps cercano nome e indirizzo, Google e Wikipedia aprono le informazioni sul posto.",
    "La base della mappa è ricalcata, non è una cartografia completa: confini dei quartieri dai dati aperti della città, Ring, Donaukanal e quattro assi tracciati sulle strade reali, più una griglia di 500 m.",
    "Sul telefono un dito scorre la pagina e due dita muovono e ingrandiscono la mappa. Il pulsante \"Sposta con 1 dito\" sotto la mappa inverte la scelta."
  ] }
];

const TODO = [
  "Scegliere voli e alloggio: tutti gli orari del venerdì e della domenica dipendono da loro.",
  "Treno per l'aeroporto: orario reale, tariffa e stato dei lavori a dicembre su oebb.at.",
  "Postsparkasse: orari di accesso alla Kassenhalle su ail.angewandte.at.",
  "Secession: tariffa d'ingresso.",
  "Stephansdom: orari di visita e aree a pagamento.",
  "Riesenrad: orario di dicembre su wienerriesenrad.com.",
  "Loos American Bar e Café Sperl: orari di apertura.",
  "Campus WU: accesso agli interni di domenica.",
  "Tram tra Hundertwasserhaus e Wien Hbf: linea e fermata in WienMobil.",
  "Deposito bagagli a Wien Hbf: disponibilità e prezzo.",
  "Posizioni di classe C: confermare su una mappa prima di partire."
];

const FONTI = [
  ["Wiener Linien - nuove tariffe dal 1 gennaio 2026", "https://www.wienerlinien.at/web/wl-en/news/new-fare-structure-from-1-january-2026"],
  ["Wiener Linien - biglietti a tempo", "https://www.wienerlinien.at/de/31-tage-wien"],
  ["ÖBB - collegamenti con l'aeroporto (PDF)", "https://www.oebb.at/dam/jcr%3A9e79fc03-e3b0-483b-bc28-76691cf84e40/folder-naechster-halt-ganze-welt-deutsch.pdf"],
  ["Vienna Unwrapped - lavori 2026 e collegamenti aeroporto (non ufficiale)", "https://vienna-unwrapped.com/?p=52811"],
  ["Secession - orari", "https://secession.at/informationen_tickets"],
  ["wien.info - WestLicht", "https://www.wien.info/de/westlicht-schauplatz-fuer-fotografie-126280"],
  ["wien.info - Postsparkasse", "https://www.wien.info/de/oesterreichische-postsparkasse-124334"],
  ["Stadt Wien - Flohmarkt al Naschmarkt", "https://www.wien.gv.at/freizeit/einkaufen/maerkte/flohmarkt/"],
  ["wien.info - Riesenrad", "https://www.wien.info/de/riesenrad-124960"],
  ["wien.info - Kunst Haus Wien", "https://www.wien.info/de/kunsthauswien-128426"],
  ["Leopold Museum - orari", "https://www.leopoldmuseum.org/en/visit/opening-hours"],
  ["Leopold Museum - biglietti", "https://www.leopoldmuseum.org/en/visit/tickets"],
  ["Confini dei quartieri - Stadt Wien via click_that_hood", "https://github.com/codeforgermany/click_that_hood"],
  ["Percorsi a piedi - OSRM su server FOSSGIS", "https://routing.openstreetmap.de/"],
  ["Dati cartografici - OpenStreetMap", "https://www.openstreetmap.org/copyright"]
];
