/* Prova su telefono simulato: node mobile-check.mjs file.html [cartella-schermate]
   Richiede puppeteer-core (npm i puppeteer-core) e Chrome o Chromium (variabile CHROME, altrimenti /usr/bin/google-chrome).
   Per ogni larghezza e ogni vista controlla: errori di script, scorrimento orizzontale della pagina, comandi troppo piccoli da toccare,
   apertura della scheda di dettaglio, funzionamento di giorni e alternative. Esce con 1 se trova problemi. */
import puppeteer from 'puppeteer-core';
import path from 'path';
const file = 'file://' + path.resolve(process.argv[2]), shots = process.argv[3] || '/tmp';
const b = await puppeteer.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox', '--disable-gpu'] });
const problems = [], report = [], wait = ms => new Promise(r => setTimeout(r, ms));
const NET = /ERR_(INTERNET|NAME|PROXY|TUNNEL|CONNECTION|BLOCKED|FAILED)/;
for (const w of [360, 390, 430]) {
  for (const dark of [false, true]) {
    if (dark && w !== 390) continue;
    const p = await b.newPage(), tag = w + (dark ? ' scuro' : '');
    p.on('pageerror', e => problems.push(`${tag}: errore di script ${e.message}`));
    p.on('console', m => { if (m.type() === 'error' && !NET.test(m.text())) problems.push(`${tag}: console ${m.text()}`); });
    await p.setViewport({ width: w, height: 780, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    if (dark) await p.emulateMediaFeatures([{ name: 'prefers-color-scheme', value: 'dark' }]);
    await p.goto(file, { waitUntil: 'load' }); await wait(600);
    const views = await p.$$eval('#tabs button', x => x.map(e => e.dataset.tab));
    const audit = async where => {
      const r = await p.evaluate(() => {
        const over = document.documentElement.scrollWidth - window.innerWidth, small = [];
        document.querySelectorAll('button, a.btn, select, input').forEach(e => {
          const c = e.getBoundingClientRect(); if (!c.width || !c.height || e.closest('[hidden]') || e.classList.contains('ev') || e.closest('.leaflet-control-attribution')) return;
          if (c.height < 32 || c.width < 32) small.push((e.id || e.className || e.tagName) + ' ' + Math.round(c.width) + 'x' + Math.round(c.height));
        });
        return { over, small: Array.from(new Set(small)).slice(0, 6) };
      });
      if (r.over > 1) problems.push(`${tag} ${where}: la pagina scorre in orizzontale di ${r.over} px`);
      if (r.small.length) problems.push(`${tag} ${where}: comandi piccoli ${r.small.join(', ')}`);
    };
    for (const v of views) {
      await p.tap('#tabs button[data-tab="' + v + '"]'); await wait(250); await audit(v);
      if (v === 'giorni') {
        const nd = await p.$$eval('#dayNav button', x => x.length);
        for (let d = 0; d < nd; d++) {
          await p.tap('#dayNav button[data-d="' + d + '"]'); await wait(250);
          const nv = await p.$$eval('#varSeg button', x => x.length);
          for (let k = nv - 1; k >= 0; k--) { await p.evaluate(i => document.querySelectorAll('#varSeg button')[i].click(), k); await wait(200); await audit('giorno ' + (d + 1) + ' programma ' + k); }
          const pinsN = await p.$$eval('.pin', x => x.length), rows = await p.$$eval('#agenda li', x => x.length);
          if (!rows) problems.push(`${tag}: agenda vuota nel giorno ${d + 1}`);
          report.push(`${tag} giorno ${d + 1}: ${rows} righe in agenda, ${pinsN} segnaposto, ${nv ? nv - 1 : 0} alternative`);
        }
        await p.tap('#dayNav button[data-d="0"]'); await wait(250);
        await p.evaluate(() => { const x = document.querySelector('#agenda li.t-visit button') || document.querySelector('#agenda li:not(.t-move) button'); x.scrollIntoView({ block: 'center' }); x.click(); }); await wait(200);
        const sh = await p.evaluate(() => { const o = document.querySelector('#overlay'), s = document.querySelector('.sheet').getBoundingClientRect(); return { open: !o.hidden, fits: s.bottom <= window.innerHeight + 1 && s.top >= 0, links: document.querySelectorAll('#sLinks a').length }; });
        if (!sh.open || !sh.fits) problems.push(`${tag}: la scheda di dettaglio non si apre o esce dallo schermo`);
        report.push(`${tag}: scheda aperta con ${sh.links} collegamenti`);
        if (w === 390) await p.screenshot({ path: `${shots}/mc-scheda${dark ? '-scuro' : ''}.png` });
        await p.evaluate(() => document.querySelector('#sClose').click()); await wait(100);
        await p.evaluate(() => window.scrollTo(0, 0));
      }
      if (w === 390) await p.screenshot({ path: `${shots}/mc-${v}${dark ? '-scuro' : ''}.png` });
    }
    await p.close();
  }
}
await b.close();
console.log(report.join('\n'));
console.log(problems.length ? '\nPROBLEMI:\n' + problems.join('\n') : '\nnessun problema su telefono simulato (360, 390, 430 px, chiaro e scuro)');
process.exit(problems.length ? 1 : 0);
