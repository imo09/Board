/* Controlli di qualità: node qa.mjs data.js [file.html] [file.md] ...
   Con un ERRORE il file non si consegna. Gli avvisi vanno letti e, se accettati, dichiarati nel messaggio di consegna. */
import fs from 'fs';
const src = fs.readFileSync(process.argv[2], 'utf8');
const D = new Function(src + '; return {TRIP,DAYS,PLACES,EVENTS,COSTS,ROUTES:typeof ROUTES!=="undefined"?ROUTES:{},BASE:typeof BASE!=="undefined"?BASE:null,VARIANTS:typeof VARIANTS!=="undefined"?VARIANTS:[]};')();
const { TRIP, DAYS, PLACES, ROUTES, BASE, EVENTS, COSTS, VARIANTS } = D;
const MAP = TRIP.map !== false;
let err = 0, warn = 0; const E = m => { err++; console.log('ERRORE  ' + m); }, W = m => { warn++; console.log('avviso  ' + m); };
const H = s => { const p = s.split(':'); return +p[0] + p[1] / 60; };
const dist = (a, b) => { const q = Math.PI / 180, x = (b[1] - a[1]) * q * Math.cos((a[0] + b[0]) / 2 * q), y = (b[0] - a[0]) * q; return Math.sqrt(x * x + y * y) * 6371000; };
function decode(str) { let i = 0, lat = 0, lng = 0; const o = []; while (i < str.length) { let b, s = 0, r = 0; do { b = str.charCodeAt(i++) - 63; r |= (b & 31) << s; s += 5; } while (b >= 32); lat += (r & 1) ? ~(r >> 1) : (r >> 1); s = 0; r = 0; do { b = str.charCodeAt(i++) - 63; r |= (b & 31) << s; s += 5; } while (b >= 32); lng += (r & 1) ? ~(r >> 1) : (r >> 1); o.push([lat / 1e5, lng / 1e5]); } return o; }
const len = p => p.slice(1).reduce((a, x, i) => a + dist(p[i], x), 0);
const jump = p => Math.max(...p.slice(1).map((x, i) => dist(p[i], x)));
const hasPos = p => p && typeof p.lat === 'number';

// 1 caratteri vietati (trattino lungo, trattino medio, punto mediano) nei dati, nella logica e nei testi
for (const f of process.argv.slice(3)) {
  const t = fs.readFileSync(f, 'utf8');
  const body = f.endsWith('.html') ? t.slice(t.indexOf('/* ============ 1. DATI')) + t.slice(0, t.indexOf('<script>')).replace(/[\s\S]*<\/style>/, '') : t;
  [0x2014, 0x2013, 0xb7].map(n => String.fromCharCode(n)).forEach(c => { const n = body.split(c).length - 1; if (n) E(f + ': ' + n + ' occorrenze di U+' + c.charCodeAt(0).toString(16)); });
}

// 2 luoghi
for (const [k, p] of Object.entries(PLACES)) {
  if (!p.n || !p.kind) E('nome o tipo mancante: ' + k);
  if (hasPos(p)) {
    if (!(p.lat > -90 && p.lat < 90 && p.lng > -180 && p.lng < 180)) E('coordinate non valide: ' + k);
    if (!'ABC'.includes(p.q) || !p.src) E('classe o fonte della posizione mancante: ' + k);
    const km = dist([p.lat, p.lng], TRIP.center) / 1000; if (!p.far && km > 15) W(k + ' a ' + km.toFixed(1) + ' km dal centro senza far:true');
  } else if (MAP) E('coordinate mancanti con la mappa attiva: ' + k);
  if (p.kind === 'poi' && !p.g) W('testo di ricerca g mancante: ' + k);
  if (!p.addr) W('indirizzo mancante: ' + k);
}

// 3 percorsi calcolati
for (const [k, r] of Object.entries(ROUTES)) {
  const pts = decode(r.poly), a = PLACES[r.stops[0]], b = PLACES[r.stops[r.stops.length - 1]];
  if (r.legs.length !== r.stops.length - 1) E(k + ': tratte e tappe non coerenti');
  const d0 = dist(pts[0], [a.lat, a.lng]), d1 = dist(pts[pts.length - 1], [b.lat, b.lng]), L = len(pts), T = r.legs.reduce((s, l) => s + l[0], 0), sp = r.legs.map(l => l[0] / l[1] * 3.6);
  console.log(`percorso ${k}: ${pts.length} punti, estremi a ${d0.toFixed(0)} e ${d1.toFixed(0)} m dalle tappe, ${L.toFixed(0)} m su ${T.toFixed(0)} dichiarati, salto massimo ${jump(pts).toFixed(0)} m, ${Math.min(...sp).toFixed(1)}-${Math.max(...sp).toFixed(1)} km/h`);
  if (d0 > 120 || d1 > 120) E(k + ': estremi lontani dalle tappe (polyline corrotta o tappa sbagliata)');
  if (Math.abs(L - T) / T > 0.12) E(k + ': lunghezza diversa oltre il 12% dal dichiarato');
  if (jump(pts) > 900) E(k + ': salto anomalo tra due punti');
  r.stops.forEach((s, i) => { if (i && i < r.stops.length - 1) { const p = PLACES[s], m = Math.min(...pts.map(x => dist(x, [p.lat, p.lng]))); if (m > 120) E(k + ': la tappa ' + s + ' dista ' + m.toFixed(0) + ' m dal percorso'); } });
}

// 4 base della mappa
if (MAP && !BASE) W('mappa senza BASE: dove la cartografia non si carica i punti restano senza contesto');
if (BASE) {
  (BASE.lines || []).forEach((l, i) => {
    const pts = decode(l.poly), L = len(pts), nm = l.n || (l.names || []).filter(Boolean).join(' + ') || 'linea ' + i;
    console.log(`base ${nm}: ${pts.length} punti, ${L.toFixed(0)} m su ${l.dist} dichiarati, salto massimo ${jump(pts).toFixed(0)} m`);
    if (!l.dist || Math.abs(L - l.dist) / l.dist > 0.12 || jump(pts) > 1500) E('base ' + nm + ': polyline non coerente');
    if (l.legs && (!l.names || l.names.length !== l.legs.length)) E('base ' + nm + ': legs e names di lunghezza diversa');
    if (dist(pts[0], TRIP.center) > 30000) E('base ' + nm + ': lontana dal centro del viaggio');
  });
  (BASE.areas || []).forEach(a => { const pts = decode(a.poly); if (pts.length < 4 || !a.at || dist(a.at, pts[0]) > 20000) E('area ' + a.n + ': poligono non valido'); });
  console.log(`base: ${(BASE.areas || []).length} aree, ${(BASE.lines || []).length} linee, ${(BASE.labels || []).length} nomi di zona`);
}

// 5 alternative
const ids = VARIANTS.map(v => v.id);
VARIANTS.forEach(v => {
  if (ids.filter(x => x === v.id).length > 1) E('variante con id ripetuto: ' + v.id);
  if (!DAYS[v.d]) E('variante con giorno non valido: ' + v.id);
  if (v.from && v.to && !(H(v.to) > H(v.from))) E('variante con finestra non valida: ' + v.id);
  if (!v.name || !v.why) W('variante senza nome o senza motivo: ' + v.id);
  if (!EVENTS.some(e => e.v === v.id)) W('variante senza eventi propri (toglie soltanto): ' + v.id);
});
EVENTS.forEach(e => { if (e.v) { const v = VARIANTS.find(x => x.id === e.v); if (!v) E(e.title + ': variante sconosciuta ' + e.v); else { if (v.d !== e.d) E(e.title + ': giorno diverso da quello della variante'); if (H(e.s) < (v.from ? H(v.from) : 0) || H(e.s) >= (v.to ? H(v.to) : 24)) W(e.title + ': inizia fuori dalla finestra della variante ' + v.id); } } });
COSTS.forEach(c => { [c.v].concat(c.x || []).filter(Boolean).forEach(id => { if (!ids.includes(id)) E('costo "' + c.desc + '": variante sconosciuta ' + id); }); });

// 6 eventi: ogni giorno viene controllato nel programma base e in ogni sua variante
const resolve = (d, id) => { const v = VARIANTS.find(x => x.id === id); return EVENTS.filter(e => e.d === d && (e.v ? e.v === id : !(v && H(e.s) >= (v.from ? H(v.from) : 0) && H(e.s) < (v.to ? H(v.to) : 24)))).sort((a, b) => H(a.s) - H(b.s)); };
DAYS.forEach((day, d) => {
  [''].concat(VARIANTS.filter(v => v.d === d).map(v => v.id)).forEach(id => {
    const tag = day.date + (id ? ' [' + id + ']' : ''), ev = resolve(d, id);
    if (!ev.length) E(tag + ': nessun evento');
    ev.forEach((e, i) => {
      if (!/^\d\d:\d\d$/.test(e.s) || !/^\d\d:\d\d$/.test(e.e)) E(`${tag} ${e.title}: orario non nel formato HH:MM`);
      if (!(H(e.e) > H(e.s))) E(`${tag} ${e.s} ${e.title}: fine non successiva all'inizio`);
      if (i && H(e.s) < H(ev[i - 1].e) - 1e-9) E(`${tag}: sovrapposizione tra "${ev[i - 1].title}" e "${e.title}"`);
      if (H(e.s) < TRIP.hours[0] || H(e.e) > TRIP.hours[1]) E(`${tag} ${e.title}: fuori dalla finestra del calendario`);
      ['p', 'from', 'to'].forEach(f => { if (e[f] && !PLACES[e[f]]) E(`${tag} ${e.title}: luogo sconosciuto ${e[f]}`); });
      if (!['visit', 'meal', 'move', 'log'].includes(e.type)) E(`${tag} ${e.title}: tipo non valido`);
      if (e.type === 'move') {
        if (!e.mode) E(`${tag} ${e.title}: mezzo mancante`);
        if (MAP && e.mode !== 'plane' && (!e.from || !e.to)) E(`${tag} ${e.title}: da/a mancanti`);
        if (e.mode === 'walk' && !e.r && MAP) W(`${tag} ${e.title}: tratto a piedi senza percorso calcolato`);
        if (e.r) { const R = ROUTES[e.r[0]]; if (!R || !R.legs[e.r[1]]) E(`${tag} ${e.title}: percorso inesistente`); else { if (R.stops[e.r[1]] !== e.from || R.stops[e.r[1] + 1] !== e.to) E(`${tag} ${e.title}: da/a diversi dalla tratta del percorso`); const need = R.legs[e.r[1]][1] / 60, have = (H(e.e) - H(e.s)) * 60; if (have < need - 0.01) E(`${tag} ${e.title}: ${have.toFixed(0)} min in calendario, ne servono ${need.toFixed(1)}`); if (have > need + 10) W(`${tag} ${e.title}: ${have.toFixed(0)} min in calendario contro ${need.toFixed(1)} calcolati`); } }
        else if (!e.detail) W(`${tag} ${e.title}: spostamento stimato senza dettaglio`);
      } else if (!e.p && !e.detail) W(`${tag} ${e.title}: evento senza luogo e senza dettaglio`);
    });
    // continuità: ogni spostamento parte dall'ultimo luogo noto, ogni evento con un luogo è raggiunto da uno spostamento
    let last = null; ev.forEach(e => { if (e.type === 'move') { if (last && e.from && e.from !== last) W(`${tag} ${e.s}: "${e.title}" parte da ${e.from} ma l'ultimo luogo è ${last}`); if (e.to) last = e.to; } else if (e.p) { if (last && e.p !== last) W(`${tag} ${e.s}: "${e.title}" è in ${e.p} senza spostamento da ${last}`); last = e.p; } else last = null; });
    const meals = ev.filter(e => e.type === 'meal').length; if (meals < 2) W(`${tag}: solo ${meals} pasti in calendario`);
  });
});

// 7 costi: totale base e differenza di ogni variante
const ST = ['Confermato', 'Prenotato', 'Stima', 'Ipotesi'], sum = a => a.reduce((t, c) => t + (c.amt || 0), 0);
COSTS.forEach(c => { if (!DAYS[c.d]) E('costo con giorno non valido: ' + c.desc); if (!ST.includes(c.st)) E('stato non valido: ' + c.desc); if (c.amt != null && !(c.amt >= 0)) E('importo non valido: ' + c.desc); });
const rows = id => COSTS.filter(c => (c.v ? c.v === id : true) && !(c.x && c.x.includes(id))), base = rows('');
console.log('totale base ' + sum(base).toFixed(2) + ' | ' + ST.map(s => s + ' ' + sum(base.filter(c => c.st === s)).toFixed(2)).join(' | ') + ' | senza importo ' + base.filter(c => c.amt == null).length);
console.log('per giorno ' + DAYS.map((x, d) => x.date.slice(8) + ': ' + sum(base.filter(c => c.d === d)).toFixed(2)).join(' | '));
VARIANTS.forEach(v => console.log('variante ' + v.id + ': totale ' + sum(rows(v.id)).toFixed(2) + ' (' + (sum(rows(v.id)) - sum(base) >= 0 ? '+' : '') + (sum(rows(v.id)) - sum(base)).toFixed(2) + ')'));

// 8 riepilogo
const q = { A: 0, B: 0, C: 0, '-': 0 }; Object.values(PLACES).forEach(p => q[p.q || '-']++);
console.log('posizioni A ' + q.A + ', B ' + q.B + ', C ' + q.C + (q['-'] ? ', senza coordinate ' + q['-'] : '') + ' | modalità ' + (MAP ? 'completa' : 'lite'));
console.log(err ? `\n${err} ERRORI, ${warn} avvisi` : `\nnessun errore, ${warn} avvisi`); process.exit(err ? 1 : 0);
