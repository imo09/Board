# Lente - schede CCNL e fondi di categoria

Versione 1.1 - ottobre 2026

Questo file è la fonte dei dati contrattuali usati da Lente. Le istruzioni (`lente-istruzioni.md`) lo consultano dopo aver letto la testata del cedolino. Contiene solo regole del contratto, mai dati di una persona.

## 1. Come si usa

1. **Ricerca della scheda:** cerca il CCNL per codice CNEL (spesso stampato in testata, per esempio "Contratto: F012") o per nome. Se non c'è una scheda, procedi senza e chiedi all'utente i dati mancanti nel pannello "Contratto e fondi".
2. **Stato di ogni dato:** "confermato" (da fonte ufficiale o da più fonti concordi), "derivato" (calcolato da dati confermati), "da verificare" (fonte unica, vecchia o parziale). I dati "da verificare" si usano solo come ipotesi dichiarata, mai per un controllo con esito verde.
3. **Etichetta nella pagina:** ogni valore preso da qui compare con l'etichetta "scheda CCNL"; se l'utente lo modifica, l'etichetta diventa "indicato da te".
4. **Validità:** controlla la data di scadenza della parte economica. Se il cedolino è successivo, segnala che i minimi potrebbero essere cambiati.
5. **Aggiornamento:** ogni modifica riporta data e fonte. Quando un cedolino reale contraddice un dato, non correggere la scheda in automatico: segnalalo e aggiorna solo dopo verifica.

## 2. Campi di una scheda

| Campo | A cosa serve nella pagina |
|---|---|
| Codice CNEL e nome | Riconoscere il contratto dalla testata |
| Categoria (operai, impiegati, quadri) | Le regole cambiano per categoria: scegli la sezione giusta |
| Mensilità aggiuntive e mese di pagamento | Ratei nel costo azienda, promemoria del mese in cui arrivano |
| Divisore giornaliero e orario | Valore di festività non godute, ex festività pagate, assenze |
| Orario settimanale | Ore lavorabili attese, conversione ore e giorni |
| Ferie annue | Ferie maturate attese, controllo dei saldi |
| Permessi per riduzione orario (ROL o simili) | Permessi maturati attesi, scadenza di fruizione |
| Ex festività | Se diventano permesso o pagamento: spiega un contatore vuoto o una voce in busta |
| Minimi per livello e contingenza | Controllo della paga base |
| Scatti di anzianità | Controllo numero e importo degli scatti |
| Elementi territoriali | Riconoscere le voci provinciali |
| Fondo pensione di categoria | Gruppo "Fondo pensione" nelle trattenute, quota azienda nel costo |
| Fondo sanitario e enti bilaterali | Costo azienda, voci figurative, dizionario |
| Scadenza parte economica | Avviso sui minimi non aggiornati |

## 3. Scheda: Edilizia industria (ANCE)

Codice CNEL in testata: F012. Parte economica: accordo del 29 gennaio 2025, in scadenza il 30 giugno 2028.

### 3.1 Impiegati

| Campo | Valore | Stato | Fonte |
|---|---|---|---|
| Mensilità aggiuntive | 13ª entro il 20 dicembre; 14ª (premio annuo) entro il 30 giugno | confermato | Guida Ediltecnico al CCNL; confermato dall'utente |
| Periodo di maturazione 14ª | Ipotesi: luglio-giugno, pagata a giugno | da verificare | - |
| Periodo di maturazione 13ª | Gennaio-dicembre, pagata a dicembre | confermato | Regola generale della gratifica natalizia |
| Divisore giornaliero | 1/25 della retribuzione mensile | confermato | Ediltecnico (art. 43-bis, 4 novembre); stipendio esposto come 25 giorni nei cedolini |
| Ferie | 4 settimane di calendario per anno di servizio (art. 62); con orario su 5 giorni, 20 giorni o 160 ore | confermato | Ediltecnico |
| Ferie a frazioni | 5 giorni lavorativi di ferie valgono una settimana con orario su 5 giorni | confermato | Ediltecnico |
| Permessi per riduzione orario | 88 ore l'anno; 1 ora ogni 20 lavorate; maturano entro il 31 dicembre, si godono entro il 30 giugno dell'anno dopo; pagati quando goduti | confermato | Ediltecnico |
| Ex festività: 4 novembre | Compenso in busta pari a 1/25 della retribuzione mensile, in aggiunta allo stipendio (art. 43-bis); non diventa permesso | confermato | Ediltecnico |
| Altre ex festività (19 marzo, Ascensione, Corpus Domini, 29 giugno) | Trattamento non trovato | da verificare | - |
| Festività di domenica | Compenso di una giornata; divisore 1/25 per coerenza con il punto precedente | da verificare | - |
| Minimo 5° livello (paga base) | 1.481,02 € dal 1° luglio 2023; 1.676,02 € dal 1° marzo 2026 | 2023 confermato, 2026 derivato | Ediltecnico per il 2023; il 2026 coincide con un cedolino reale ed è coerente con gli aumenti dell'accordo 2025 riparametrati |
| Contingenza | 8° e 7° livello 533,82 €; 6° 529,63 €; 5° 523,35 €; 4° 521,25 €; 3° 519,16 €; 2° 516,43 €; 1° 512,87 € | confermato | Ediltecnico, coincide con il cedolino reale per il 5° livello |
| EDR | 10,33 € al mese, tutti i livelli | confermato | Ediltecnico |
| Aumenti accordo 2025 | 1° livello: +80,00 € da febbraio 2025, +50,00 € da marzo 2026, +50,00 € da marzo 2027; gli altri livelli in proporzione al parametro | confermato per il 1° livello | Ediltecnico |
| Scatti di anzianità | Biennali, massimo 5; importi per livello da verificare (la tabella della fonte è incoerente) | da verificare | Ediltecnico |
| Elemento territoriale | Importo fissato dal contratto integrativo della provincia di lavoro; in busta può chiamarsi E.R.TER. o simile | da verificare | Struttura del CCNL; sigla letta da un cedolino reale |
| Assunti dal 1° luglio 2026 | Adesione automatica a Prevedi se non si sceglie diversamente entro 60 giorni (vedi 4.1) | confermato | Nota informativa Prevedi |

### 3.2 Operai

| Campo | Valore | Stato | Fonte |
|---|---|---|---|
| Ferie | 4 settimane, 160 ore di orario normale (art. 15); pagate tramite Cassa Edile | confermato | Ediltecnico |
| Permessi | 1 ora ogni 20 lavorate, fino a 88 ore l'anno; pagati a ogni periodo di paga con una maggiorazione del 4,95% | confermato | Ediltecnico |
| 4 novembre | Importo pari a 8 ore di retribuzione, 9,6 ore per i discontinui | confermato | Ediltecnico |
| Ferie e gratifica natalizia | Non in busta come rateo: l'azienda accantona il 18,5% (8,5% ferie, 10% gratifica) presso la Cassa Edile | confermato | Ediltecnico |
| Contributo Cassa Edile | 14,20% (dato riportato dalla fonte, varia per provincia) | da verificare | Ediltecnico |

## 4. Fondi di categoria

### 4.1 Come funziona un fondo pensione negoziale

1. **Chi versa:** il lavoratore (una percentuale minima, più eventuali quote volontarie), l'azienda (una percentuale, solo se il lavoratore versa la sua) e il TFR (tutto o in parte).
2. **Contributo contrattuale:** alcuni CCNL prevedono un importo fisso a carico azienda, dovuto anche a chi non aderisce pienamente.
3. **Effetto sul netto:** la quota del lavoratore è una trattenuta, ma è deducibile entro 5.164,57 € l'anno: riduce l'imponibile IRPEF del mese, quindi il netto cala meno della quota versata.
4. **Effetto sul TFR:** il TFR conferito esce dal fondo TFR aziendale e va al fondo pensione ogni mese, al netto dello 0,50% di contributo al fondo di garanzia.
5. **Dove compare nel cedolino:** quote del lavoratore tra le trattenute; quota azienda, contributo contrattuale e TFR conferito spesso solo nel riquadro TFR o fondi, come voci figurative.
6. **Come mostrarlo in Lente:** quote del lavoratore nel gruppo "Fondo pensione" delle trattenute; quota azienda e contributo contrattuale nel costo azienda; TFR conferito e totale versato nel mese nei Saldi, sotto "Accantonato per te".
7. **Controlli:** TFR conferito = quota TFR del mese meno lo 0,50%; quota azienda presente se il lavoratore versa la sua; imponibile fiscale ridotto della quota del lavoratore.

### 4.2 Prevedi (edilizia)

| Campo | Valore | Stato | Fonte |
|---|---|---|---|
| Settore | Fondo pensione dei lavoratori edili | confermato | Prevedi |
| Lavoratore | 1,00% della retribuzione, più eventuali quote volontarie | confermato | Nota informativa Prevedi |
| Azienda | 1,00% della retribuzione, attivato insieme all'1,00% del lavoratore | confermato | Nota informativa Prevedi |
| TFR | 18% o 100% a scelta; 100% se non indicato | confermato | Nota informativa Prevedi |
| Contributo contrattuale | Importo fisso a carico azienda fissato dagli accordi; dovuto anche a chi sceglie un altro fondo o lascia il TFR in azienda, per contratti oltre 3 mesi | confermato; importo da leggere nel cedolino | Nota informativa Prevedi |
| Adesione automatica | Dal 1° luglio 2026, per i neoassunti al primo impiego o con TFR già conferito a un fondo: senza modulo TFR3 entro 60 giorni scatta l'adesione piena (1% + 1% + TFR 100% + contributo contrattuale) | confermato | Nota informativa Prevedi |
| Già in forza al 30 giugno 2026 | Esclusi dall'adesione automatica | confermato | Nota informativa Prevedi |
| Modifiche | Le quote dell'1,00% o il TFR si possono attivare anche dopo, con il modulo di integrazione, dal mese della firma | confermato | Nota informativa Prevedi |
| Contatti | info@prevedi.it, 06 88803520 | confermato | Nota informativa Prevedi |

### 4.3 Sanedil (sanità integrativa edilizia)

| Campo | Valore | Stato | Fonte |
|---|---|---|---|
| Chi è coperto | Operai e impiegati | confermato | ANCE, ottobre 2020 |
| Contributo | Interamente a carico azienda; impiegati 0,26%, operai 0,60% | da verificare (dato 2020) | ANCE, ottobre 2020 |
| Base di calcolo | Minimo, contingenza, EDR, indennità territoriale di settore; escluso il superminimo | da verificare (dato 2020) | ANCE, ottobre 2020 |
| In busta | Non è una trattenuta; può comparire come voce figurativa | confermato | ANCE, ottobre 2020 |
| Come mostrarlo | Nel costo azienda come "stima" se non letto in busta; nel pannello "Contratto e fondi" | regola Lente | - |

### 4.4 Cassa Edile

1. **A chi serve:** agli operai. L'azienda accantona presso la Cassa Edile le somme per ferie e gratifica natalizia, che la Cassa paga poi all'operaio.
2. **Per gli impiegati:** ferie, 13ª e 14ª sono pagate in busta; la Cassa Edile di norma non compare.
3. **Come mostrarlo:** per gli operai, nel costo azienda e con una nota che ferie e gratifica non arrivano dalla busta paga.

## 5. Fonti

1. [Ediltecnico - CCNL Edilizia Industria: livelli, mensilità e ferie](https://ediltecnico.it/ccnl-edilizia-industria-la-guida-completa-su-livelli-mensilita-e-ferie/)
2. [Ediltecnico - Ferie e permessi nei CCNL dell'edilizia](https://ediltecnico.it/ferie-permessi-congedo-matrimoniale-ccnl-edilizia/)
3. [Ediltecnico - Festività soppressa del 4 novembre in edilizia](https://ediltecnico.it/?p=120589)
4. [Prevedi - Note informative sull'adesione automatica dal 1° luglio 2026](https://prevedi.it/public/php_popup/documenti/65_Note_informative_Prevedi_inerenti_all_adesione_automatica_in_vigore_dal_1_luglio_2026.pdf)
5. [ANCE - Aliquote Sanedil e Cassa Edile da ottobre 2020](https://ance.it/2020/10/aliquote-del-contributo-sanedil-e-del-contributo-casse-edile-da-ottobre-2020/)

## 6. Schede da aggiungere

1. Commercio e terziario (Confcommercio)
2. Metalmeccanica industria (Federmeccanica)
3. Altri CCNL in base ai cedolini che arrivano; prima di scegliere i più diffusi, verificare i dati dell'archivio CNEL.
